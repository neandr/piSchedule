#!/bin/bash
GITdoc='https://neandr.github.io/piSchedule'

NAME='schedulePlus3'
VDATE='2020-10-22_1'
VERSION='3.0.4'

ZIPP=$NAME.zip
SH='Setup.sh'
SH=$NAME$SH

  bw=$'\033[1m'                  # bold
  br=$'\033[1;38;5;196m'         # bold red
  ba=$'\033[1;38;5;16;48;5;15m'  # bold black on white
  bg=$'\033[1;38;5;28;48;5;7m'   # bold green on white
  bb=$'\033[1;38;5;21;48;5;7m'   # bold blue on white
  e0=$'\033[0m'                  # reset/normal

T=" ___ $NAME Setup  #$VERSION     $VDATE ___"
H="
    SYNOPSIS
      $SH [ARGUMENT]

    DESCRIPTION
      '$NAME' ist verfügbar auf Github als ZIP.

      Das ZIP beinhaltet ein Verzeichnis '$NAME' mit dem notwendigen Code
      und dieses Setup-Script, das die zusätzlichen Libraries
      lädt und Parameter für die Laufzeit von '$NAME' setzt.

      Von Github werden das ZIP und das 'schedulePlus3Setup.sh' abgerufen mit:
         $ba cd ~  &&  wget https://neandr.github.io/piSchedule/$NAME.zip           $e0
         $ba unzip -p $NAME.zip schedulePlus3Setup.sh > schedulePlus3Setup.sh       $e0
         $ba chmod 755 schedulePlus3Setup.sh                                        $e0

      Für das abgerufene ZIP wird die SHA-256 Prüfsumme kontrolliert,
      bei der Installation (siehe Argument '-i') werden die ZIP Prüfsummen
      der GIT Datei und die der abgerufenen angegeben.

      Die ZIP-Datei und dieses Skript '$SH' werden im einem
      übergeordneten Verzeichnis von '$NAME' gespeichert und ausgeführt,
      d.h. der Verzeichnisbaum sieht so aus:

       ../pi/                      oder ein anderes übergeordnetes Verzeichnis
         |__schedulePlus3.zip      ev. weitere Versionen
         |__schedulePlus3Setup.sh  dieses Script
         |
         |__schedulePlus3/         hier ist der '$NAME' Code nach der Installation
                                   gespeichert und wird dort ausgeführt
"
A="
    ARGUMENT
      no argument         Zeigt Version/Datum und momentanes Verzeichnis
      '--help'            Prompt dieses 'Help' Textes

      '-l' '--libs'       Laden der Python/bash Bibliotheken (Python, Bottle, jp etc)
      '-i' '--install'    Installation der '$NAME' Funktionen mit Auswahl einer
                            lokalen ZIP Datei, Default ist ($NAME.zip)
      '-c' '--configure'  Konfigurieren des '$NAME' Systems, siehe auch
                            Dokumentation zum ersten Starten des Systems

    Dokumentation  $GITdoc
"


echo "$T"

   xDIR="$(pwd)"
   baseDIR="$(dirname $xDIR)"
   currentDIR="$(basename $xDIR)"

   echo "        xDir: " $xDIR        #  /home/pi
   echo "     baseDIR: " $baseDIR     #  /home
   echo "  currentDIR: " $currentDIR  #  pi
   echo " Default ZIP: " $ZIPP        # schedulePlus3
   echo -e

#----------------------------------------------
function install_it ()
{
   echo "   ... install_it  $WHAT"
   INSTALL_STAT=`sudo pip3 install $WHAT`
   IS_STAT=$(( ! $(grep -iq 'satisfied:' <<< "$INSTALL_STAT"; echo $?) ))
   echo "   ...     status  '$IS_STAT' '$INSTALL_STAT'"
}

function LibsLoad ()
{
   echo -e "\n   *** Python libraries loaded for '$NAME'.\n"

   echo "   ... Install python3-pip ..."
   sudo apt-get install python3-pip

   WHAT='apscheduler'
   install_it $WHAT

   WHAT='bottle'
   install_it $WHAT

   WHAT='python-dateutil'
   install_it $WHAT

   WHAT='jq'
   sudo apt-get install $WHAT
}

function SystemInstall ()
{
   # unzip code,
   # if directory already exsist, don't extract /data directory
   #   not to overwrite user data, see /data.org for default etc
   echo -e "\n    ---  Checking for '$NAME'"
   if [[ -d $NAME ]] ;  then
      echo -e  "\n!!! ---  '$NAME/' exists already.\n"
      echo -e    "    ---  Code from $ZIPP will be deflated to '/$NAME' directory,"
      echo -e    "    ---  excluding '$NAME/data' .. so personell data isn't lost."
      unzip -o $ZIPP -x $NAME/data/* schedulePlus3Setup.sh

    else
      echo -e  "\n!!! ---  '$NAME/' .. Does NOT EXISTS! Will be created.\n"
      if ! mkdir $NAME/ ; then
         echo -e "??? ---  '$NAME/' .. Could not create. Error!'"
         exit 102
      else
         echo -e "    ---  '$NAME' code will be installed from '$ZIPP'."
         unzip -o $ZIPP -x schedulePlus3Setup.sh
      fi
   fi
}

function SystemConfigure()     #Configure schedulePlus
{
   echo -e "   --- Activate '$NAME'"

   chmod 755 $NAME/piSchedule.sh

   chmod 755 $NAME/piGeoDetails.py
   chmod 755 $NAME/piPrefs.py
   chmod 755 $NAME/piSchedule.py
   chmod 755 $NAME/routerAndMe.py
   chmod 755 $NAME/suntime.py


   #  --- service setup
   if [ -f $NAME/piSchedule.sh ] ; then
     sudo service piSchedule stop 2>/dev/null      # make sure NO schedulePlus is running!

     R='/DIR=/c\DIR='$xDIR/$NAME
     sed -i $R $NAME/piSchedule.sh
   else
     echo -e "\n

       NOTE   Missing $NAME components!
              Check the directory for
              >>$NAME/piSchedule.sh<<
           \n"
     exit 9
   fi

   sudo cp $NAME/piSchedule.sh /etc/init.d/piSchedule
   sudo update-rc.d piSchedule defaults

   #port=$(jq '. | .port' $xDIR/$NAME/data/piSchedule.prefs.json)

   port=$(sed 's/, "/\n/g' $xDIR/$NAME/data/piSchedule.prefs.json | egrep "port" | tr -d '":a-zA-Z ')
	addr=$(echo $(hostname -I) | tr -d ' ')

   echo -e "\n

      $ba    Starting 'schedulePlus' now                   $e0

      IMPORTANT If failed ... check with the following commands
      $bg  Run them in the directory '$NAME'       $e0
      $bw    $ cd $xDIR/$NAME            $e0

        $  service piSchedule status
        $  ./piPrefs.py
        $  ps ax|grep piSchedule

      ... see also log-file:
        $  cat logs/piInfo.log
        $  cat logs/piSystem.log

      $bw With valid results  'piSchedule'  will start.    $e0
      $bw Startup needs a minute, so wait a little before  $e0
      $bw opening 'piSchedule in the browser with:         $e0

      $ba Press Cntrl and mouse point to this link         $e0
               $bb http://$addr:$port $e0
      $ba 'piSchedule' shows up in your browser  $bg Enjoy ;) $e0
          (Eventually you have to reload the page)

    "
   sudo service piSchedule start
   #sudo service piSchedule status

   exit 0
}


function shatest()
{
   echo -e "   !!!  ZIP Datei SHA256 Check\n"\
   "    abgerufene Datei: $(cat $ZIPP | sha256sum | head -c 64)"

   echo -e ""\
   "    GIT Prüfsumme   : $(wget  -qO- https://neandr.github.io/piSchedule/$ZIPP.sha)"

}

function getZip()
{
         echo -e "   *** ZIP Auswahl zur Installation, Default ist ($NAME.zip) "

         if ! zipps=$(dir -m *.zip | tr '\n' ' '); then
            echo -e "???    No ZIPs found!"
            exit 99
         fi

         IFS=\, read -a zips <<<"$zipps"
         n=0
         for x in "${zips[@]}" ;do
            xDate=$(date -r $x  "+%Y-%m-%d_%H:%M:%S")
            echo "       $n : $xDate   [$x]"
            ((n=n+1))
            done

         read -n 1 -p "     Auswahl für die Installation ? " No ;
         if [[ $No == ?(-)+([0-9]) && ${zips[$No]} ]] ; then
               ZIPP=$(echo ${zips[$No]} | tr -d ' ')
         else
            echo -e "$br No ZIP selected. Terminating! $e0"
            exit 1
         fi

         echo -e  "\n   ---  ZIP für die Installation:  '$ZIPP'"
         shatest
}

#==============================================

function unzip_2_tmp()
{
   # --- deflate the requested ZIP to a tmp directory ---
   if [ -d tmp/ ] ;  then
      echo -e "!!! ---  '/tmp already exists!"

      read -n 1 -p "*** ---  Overwrite  Y/n? " Qa ;
      echo -e  "\n"
       if [[ ! $Qa == 'Y'  ]] ; then
          echo -e  "\n"
          exit 11
       fi

      rm -R tmp/
   fi

   echo -e "    --- unzipp '$ZIPP' to tmp/ directory "
   unzip -o $ZIPP -d tmp/

 exit 0
}

#==============================================

   # Check not to operate on $NAME directory,
   # should work on it's parent directory!
   if [[ $currentDIR == '$NAME' ]] ; then
      echo -e "\n!!! ---  Current dir is '$NAME'"
      echo -e   "!!! ---  Script should not excecuted here!\n"
      exit 100
   fi

   while (( "$#" )); do
     case "$1" in

      --help)
         echo "$H$A"; exit 0
         ;;

      --Z)
         getZip
         shatest
         shift 1
         ;;

      -l|--libs)
         echo "   ... Bibliotheken laden (Python, Bottle, jq etc ..) ";
         cmd=LibsLoad; shift 1
         ;;

      -i|--install)
         getZip
         shatest
         echo "   ... System installieren von ZIP"
         cmd=SystemInstall; shift 1
         ;;

      -c|--configure)
         echo "   ... System konfigurieren";
         cmd=SystemConfigure; shift 1
         ;;


      *)
         echo "$A"; exit 0
         ;;

     esac
   done
   echo "   ... Aufruf '$cmd' mit ZIP '$ZIPP'"
   $cmd
   exit 0
