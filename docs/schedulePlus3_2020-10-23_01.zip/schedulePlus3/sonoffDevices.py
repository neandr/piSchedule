#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
    Copyright (C) 2015 - 2020 gWahl
'''
cVersion = "2020-10-21_00"

# Based on
# https://stackoverflow.com/questions/53633014/python-socket-getting-lan-connected-server-host-names

import socket, sys, json
import urllib.request
from timeit import default_timer as timer

from threading import Thread

def getIPbase():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))
    ipBase = s.getsockname()[0]
    s.close()

    ipBase = ipBase.split('.')
    return "%s.%s.%s" % (ipBase[0],ipBase[1],ipBase[2])


def _searchForSingleIP(ipBase, ip, ipDev):
    _ip = "%s.%s" % (ipBase, str(ip))
    try:
        s = socket.gethostbyaddr(_ip)
        if ("sonoff-" in s[0]) or ("tasmota-" in s[0]):
            ipDev.append([ip, s[0]])
    except:
        pass

def _deviceStatus(ipBase, ip, dsonoffs):
    _ip = "%s.%s" % (ipBase,str(ip))
    modes = {
        'status': '/cm?cmnd=status', \
        'module': '/cm?cmnd=module', \
        'power':  '/cm?cmnd=power', \
        'power1': '/cm?cmnd=power1', \
        'power2': '/cm?cmnd=power2', \
        'power3': '/cm?cmnd=power3', \
        'power4': '/cm?cmnd=power4' \
    }

    try:
        with urllib.request.urlopen('http://' + _ip + modes['status']) as response:
            _status = json.loads(response.read())['Status']

        with urllib.request.urlopen('http://' + _ip + modes['module']) as response:
            _module = json.loads(response.read())['Module']

        power = _status['Power']
        friendlyName = (_status['FriendlyName'])
        dsonoffs[friendlyName[0]] = { 'ip': ip, "state": power, "status": _status, "module": _module}

    except:
        pass
        print(" ... deviceStatus failed for  ip: ", ip)


def getDevices(ipfirst,iplast):

    ipDevices = []
    dsonoffs = {}

    jDevices = "data/sonoff.json"           #TODO
    with open(jDevices) as f:
        _devices = (json.load(f))

    ipBase = getIPbase()

    for i in range(ipfirst,iplast):  ## ---> ipDevices
        worker = Thread(target = _searchForSingleIP, args = (ipBase, i, ipDevices))
        worker.start()
        worker.join(timeout=0.05)

    _ipDevices = str(ipDevices).replace('], [','],\n[')
    print(_ipDevices)

    for dev in ipDevices:   ## --->  dsonoffs
        worker = Thread(target = _deviceStatus, args = (ipBase, dev[0], dsonoffs))
        worker.start()
        worker.join(timeout=0.2)


    for dev in _devices:
        _devices[dev]['active'] = 0
        if dev in dsonoffs:
            _devices[dev]['active'] = 1
            power = dsonoffs[dev]['status']['Power']
            module = dsonoffs[dev]['module']

            friendlyNames = dsonoffs[dev]['status']['FriendlyName']
            for num, name in enumerate(friendlyNames):
                if name in _devices:
                    _devices[name]['active'] = 1
                    _devices[name]['module'] = module
                    _devices[name]['state'] = power

    #return(_devices, dsonoffs)
    return(_devices)

if __name__ == '__main__':
    # limit range for performance !
    ipfirst = 2
    iplast  = 65

    if (len(sys.argv) == 3):
        ipfirst = int(sys.argv[1])
        iplast = int(sys.argv[2])

    start0 = timer()
    devices = getDevices(ipfirst, iplast)
    stop0 = timer()

    print(json.dumps(devices, indent=3))
    print (f"** elapse time ** {(stop0 - start0):{8}.{3}} sec")

    # Example for devices:
    '''
        [[50, 'sonoff-4316.fritz.box'],
        [51, 'sonoff-3126.fritz.box'],
            ...
        [57, 'tasmota-C6FFF2C-3214.fritz.box'],
            ...
        [63, 'sonoff-4065.fritz.box']]
    '''
