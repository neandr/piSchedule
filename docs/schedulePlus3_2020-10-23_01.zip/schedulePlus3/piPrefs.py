#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys, json, socket, platform


prefs = {}
prefs['version'] = "0.8.3.2"  #2020-09-21_00

# --- user data ------------------------------------------------
prefs['locale'] = 'DE'

prefs['latitude'] = '51.2558'
prefs['longitude'] = '6.9705'
prefs['sunset'] = '2015-07-16 21:00:30.00000'
prefs['sunrise'] = '2015-07-16 05:00:04.00000'

prefs['switchTime'] = 0

prefs['ipfirst'] = 50
prefs['iplast'] = 65

prefs['iniFile'] = 'newDaySchedule.ini'
prefs['weekSchedule'] = {}
prefs['newsDate'] = ''
prefs['dayPlanActive'] = 1
# ------------------------------------------------ user data ---

# --- system ---------------------------------------------------
prefs['sonoffjson'] = 'data/sonoff.json'
prefs['prefsjson'] =  'data/piSchedule.prefs.json'

prefs['routerip'] = ""
prefs['port'] = 5005
# --------------------------------------------------- system ---

# --- piSchedule setup -----------------------------------------
prefs['piDocs'] = "https://neandr.github.io/piSchedule/"
prefs['news'] = prefs['piDocs'] + 'newsplus.txt'  #  'news.txt'

logInfoName = "logs/piInfo.log"
logSysName =  "logs/piSystem.log"
logging = "trace"
# ----------------------------------------- piSchedule setup ---

def getServer():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))
    ip = s.getsockname()[0]
    x = socket.gethostbyaddr(ip)[0]
    host = x.replace(x.split(".")[0]+'.','')
    #dev print(" host name: ", host)
    s.close()
    return ip, host


def getPrefs():
    global prefs, prefsJSONfile, sonoffs

    sonoffs = {}
    with open(prefs['sonoffjson']) as data_file:
       sonoffs = json.load(data_file)

    xprefs= {}
    try:
        with open(prefs['prefsjson']) as data_file:
           xprefs = json.load(data_file)
        xprefs['status'] = '1'

    except:
        xprefs['status'] = 0

    for p in prefs:
        if p not in xprefs:
            xprefs[p] = prefs[p]

    xprefs['version'] = prefs['version']
    xprefs['sonoffjson'] = prefs['sonoffjson']
    xprefs['prefsjson'] = prefs['prefsjson']

    xprefs['server'], xprefs['servername'] = getServer()
    xprefs['routerip'] = socket.gethostbyname(xprefs['servername'])
    ip_parts = xprefs['routerip'].split('.')
    xprefs['baseIP'] = "%s.%s.%s." % (ip_parts[0],ip_parts[1],ip_parts[2])

    xprefs['platform'] = platform.uname()[1] + " -- " + str(platform.platform()).replace("'","")
    xprefs['logging'] =  logging

    # write updated prefs file
    f = open(prefs['prefsjson'], 'w')
    f.write(json.dumps(xprefs))
    f.close()

    print("\n  ** piPrefs:  prefs **")
    print(json.dumps(xprefs, indent=3))

    print("\n  ** piPrefs: sonoffs **")
    print(json.dumps(sonoffs, indent=3))

    return xprefs, sonoffs

#-------------------------------------------
if __name__ == '__main__':

    prefs, sonoffs =  getPrefs()

    sys.exit (prefs['status'])
