#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
    Copyright (C) 2015 - 2020 gWahl
'''
cVersion = "2020-10-21_14"

import socket, subprocess,sys

def getIPbase():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))
    ipBase = s.getsockname()[0]
    s.close()

    #ipBase = ipBase.split('.')
    #return "%s.%s.%s" % (ipBase[0],ipBase[1],ipBase[2])
    return ipBase

if __name__ == '__main__':
    ipBase = getIPbase()
    result = (socket.gethostbyaddr(ipBase))
    sys.exit ([ipBase, result])
