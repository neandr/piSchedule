#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import print_function

import sys, os

def main():

    try:
        calling = sys.argv[1]
    except:
        calling = ""

    if (len(sys.argv) == 1) or (calling == "--help"):
        print ("""  --- makeXX Help
 
    makeXX complements 
    a docu 'sourceDoc.html' to a 'destinationDocu.html' to 
    include bootstrap directives and sets additional control
    parameters (eg. bookmarks)  

    http://markable.in/editor/ is used to define a markup file 'source.md'
    which is stored with File --> "Export to HTML", the 'source.md.html' 

    'makeXX' handles the 'source.md.html' and an 'masterDoc.html' to 
    finally generate the 'destination.html'.

    The 'source.md.html' should have the following directives:
        <!-- lang="{code}" -->     supported:  DE  and EN, others are ignored 
                                   and no 'donation' or 'freeProject' is added;
                                   see also MASTERdoc.html for details
        <!-- title="{string, will be used for html title}" -->
        <!-- base="{url root for documents and pictures}" -->
        <!-- donation -->     Note: if included in sourcDoc a donation line is added


    Call:
        makeXX.py [ source.md.html ]  [ destination.html ] 
    Parameter:
        source.md.html        html/md document file name of page or '--help' 

    """)
        exit()

    language = ""
    title = ""
    link = ""
    doc = "destination.html"
    donation = False

    try:
        source = sys.argv[1]
        newDoc = sys.argv[2]
    except:
        pass

    try:
        with open(source, 'r') as infile:
             docLines = infile.read()  # Read file content
        dLines = docLines.splitlines()
    except:
        print(" makeXX  error:   source.md.html not found!")
        exit()

    keys = "<!-- keys\n  "

    '''
       Read control parameters from 'source'
    '''
    for dLine in dLines:
        if '<!-- lang=' in dLine:
            language = dLine.split('"')[1]

        if '<!-- title=' in dLine:
            title = dLine.split('"')[1]

        if '<!-- base=' in dLine:
            link = dLine.split('"')[1]
            docLines = docLines.replace(link, "")

        if '<!-- doc=' in dLine:
            newDoc = dLine.split('"')[1]

        if '<!-- donation -->' in dLine:
            donation = True 


        '''
        Setting a bookmark:
           use id{space}{bookmarktext} to replace a 'id' with id="{bookmarktext}"
           example:
             <h4 id="wochenplan"><id weekPlan/>Wochenplan</h4>
             <h4 id="weekPlan">Wochenplan</h4>
        '''


        if ('<id ' in dLine):
            ida = dLine.find('<id ')
            ide = dLine.find('/>')
            key = dLine[ida+4:ide]
            idx = dLine[ida:ide+2]
            dLine = dLine.replace(idx, "", 1)

            id1 = dLine.find('id=')
            id2 = dLine.find('>', id1)
            idy = dLine[id1+4:id2-1]
            dLine = dLine.replace(idy,key)

            keys = keys + key + "\n  "

        
    keys = keys + "-->\n\n"

    if len(sys.argv) == 3:
       newDoc = sys.argv[2]

    if language != "":
       newDoc = language + "/" + newDoc

    print(' ** new doc: ' + newDoc+ '  #:' + str(sys.argv))
    print(keys)

    doc = open(newDoc,'w')

    # Read the contents of the MASTERdoc
    master = 'MASTERdoc.html'
    with open(master, 'r') as infile:
        mdoc = infile.read() 
    mLines = mdoc.splitlines()


    startLine = False
    endLine = False

    for xLine in mLines:

        if '<div>  <!-- $$$content$$$ -->' in xLine:
            #print (str(xLine + '\n'))
            doc.write(str(xLine))
            doc.write("\n" + str(keys))

            for dLine in dLines:
                if '<!-- lang=' in dLine:
                    startLine = True
                if '<END/>' in dLine:
                    endLine = True
                    dLine = dLine.replace('<END/>', '')

                if ('<id ' in dLine):
                    ida = dLine.find('<id ')
                    ide = dLine.find('/>')
                    ids = dLine[ida+4:ide]

                    idx = dLine[ida:ide+2]
                    dLine = dLine.replace(idx, "", 1)
         
                    id1 = dLine.find('id=', 0, ida)
                    id2 = dLine.find('>', id1)
                    idy = dLine[id1+4:id2-1]
                    dLine = dLine.replace(idy,ids)
 

                if (startLine == True) and (endLine == False):
                    doc.write (str(dLine) + "\n")


        else: 
            if '<title>' in xLine:
                xLine = '      <title>' + title + '</title>'

            if '<base href=' in xLine:
                xLine = '      <base href="' + link + '" >'

            if ('id="$$$donation' + language) in xLine and donation == True :
                if language == "DE":
                    xLine = '<p align="center" id="donationDE" style="display:block">'
                if language == "EN":
                    xLine = '<p align="center" id="donationEN" style="display:block">'

            if ('id="$$$freeProject' + language) in xLine:
                if language == "DE":
                    xLine = '<p align="center" id="freeProjectDE" style="display:block">'

                if language == "EN":
                    xLine = '<p align="center" id="freeProjectEN" style="display:block">'

            doc.write (str(xLine) + "\n")

    doc.close()

    print(" make 'doc'   >>" + str(newDoc) + "<<\n with 'title' >>" + str(title) + "<<")


#---------------------------------
if __name__ == "__main__":

    main()
