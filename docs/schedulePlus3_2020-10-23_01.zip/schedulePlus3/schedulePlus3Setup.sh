#!/bin/bash
GITdoc='https://neandr.github.io/piSchedule'

NAME='schedulePlus3'
VDATE='2020-10-22_12'
VERSION='3.0.5'

ZIPP=schedulePlus3.zip

  bw=$'\033[1m'                  # bold
  br=$'\033[1;38;5;196m'         # bold red
  ba=$'\033[1;38;5;16;48;5;15m'  # bold black on white
  bg=$'\033[1;38;5;28;48;5;7m'   # bold green on white
  bb=$'\033[1;38;5;21;48;5;7m'   # bold blue on white
  e0=$'\033[0m'                  # reset/normal

T=" ___ schedulePlus3 Setup  #$VERSION     $VDATE ___"
H="
    SYNOPSIS
      schedulePlus3Setup.sh [ARGUMENT]

    DESCRIPTION
      'schedulePlus3' ist verfügbar auf Github als ZIP.

      Das ZIP beinhaltet ein Verzeichnis 'schedulePlus3' mit dem notwendigen Code
      und dieses 'schedulePlus3Setup.sh'-Script, das die zusätzlichen Libraries
      lädt und Parameter für die Laufzeit von 'schedulePlus3' setzt.

      Von Github werden das ZIP und das 'schedulePlus3Setup.sh' abgerufen mit:
         $ba cd ~  &&  wget https://neandr.github.io/piSchedule/schedulePlus3.zip     $e0
         $ba unzip -p schedulePlus3.zip schedulePlus3Setup.sh > schedulePlus3Setup.sh $e0
         $ba chmod 755 schedulePlus3Setup.sh                                          $e0

      Für das abgerufene ZIP wird die SHA-256 Prüfsumme kontrolliert,
      bei der Installation (siehe Argument '-i') werden die ZIP Prüfsummen
      der GIT Datei und die der abgerufenen zum Vergleich angegeben.

      Die ZIP-Datei und dieses Skript 'schedulePlus3Setup.sh' werden im einem
      übergeordneten Verzeichnis von 'schedulePlus3' gespeichert und ausgeführt,
      d.h. der Verzeichnisbaum sieht so aus:

       ../pi/                      oder ein anderes übergeordnetes Verzeichnis
         |__schedulePlus3.zip      ev. weitere Versionen
         |__schedulePlus3Setup.sh  dieses Script
         |
         |__schedulePlus3/         hier sind die 'schedulePlus3' Funktionen gespeichert
                                   und werden dort nach der Installation ausgeführt
"
A="
    ARGUMENT
      no argument         Zeigt Version/Datum und momentanes Verzeichnis
      '--help'            Prompt dieses 'Help' Textes

      '-l' '--libs'       Laden der Python/bash Bibliotheken (Python, Bottle etc)
      '-i' '--install'    Installation der 'schedulePlus3' Funktionen mit Auswahl
                            einer lokalen ZIP Datei, Default ist (schedulePlus3.zip)
      '-c' '--configure'  Konfigurieren des 'schedulePlus3' Systems, siehe auch
                            Dokumentation zum Einrichten der individuellen Installation

    Dokumentation  $GITdoc
"


echo "$T"

   xDIR="$(pwd)"
   baseDIR="$(dirname $xDIR)"
   currentDIR="$(basename $xDIR)"

   echo "        xDir: " $xDIR        #  /home/pi
   echo "     baseDIR: " $baseDIR     #  /home
   echo "  currentDIR: " $currentDIR  #  pi
   echo " Default ZIP: " $ZIPP        #  schedulePlus3
   echo -e

#----------------------------------------------
function install_it ()
{
   echo "   ... install_it  $WHAT"
   INSTALL_STAT=`sudo pip3 install $WHAT`
   IS_STAT=$(( ! $(grep -iq 'satisfied:' <<< "$INSTALL_STAT"; echo $?) ))
   echo "   ...     status  '$IS_STAT' '$INSTALL_STAT'"
}

function LibsLoad ()
{
   echo -e "\n   *** Python libraries loaded for 'schedulePlus3'.\n"

   echo "   ... Install python3-pip ..."
   sudo apt-get install python3-pip

   WHAT='apscheduler'
   install_it $WHAT

   WHAT='bottle'
   install_it $WHAT

   WHAT='python-dateutil'
   install_it $WHAT
}

function SystemInstall ()
{
   # unzip code,
   # if directory already exsist, don't extract /data directory
   #   not to overwrite user data, see /data.org for default etc
   echo -e "\n    ---  Checking for 'schedulePlus3'"
   if [[ -d schedulePlus3 ]] ;  then
      echo -e  "\n!!! ---  'schedulePlus3/' exists already.\n"
      echo -e    "    ---  Code from $ZIPP will be deflated to 'schedulePlus3' directory,"
      echo -e    "    ---  excluding 'schedulePlus3/data' .. so individuel data isn't lost."
      unzip -o $ZIPP -x schedulePlus3/data/* schedulePlus3Setup.sh

    else
      echo -e  "\n!!! ---  'schedulePlus3/' .. Does NOT EXISTS! Will be created.\n"
      if ! mkdir schedulePlus3/ ; then
         echo -e "??? ---  'schedulePlus3/' .. Could not create. Error!'"
         exit 102
      else
         echo -e "    ---  'schedulePlus3' code will be installed from '$ZIPP'."
         unzip -o $ZIPP -x schedulePlus3Setup.sh
      fi
   fi
}

function SystemConfigure()     #Configure schedulePlus
{
   echo -e "   --- Activate 'schedulePlus3'"

   chmod 755 schedulePlus3/piSchedule.sh

   chmod 755 schedulePlus3/piGeoDetails.py
   chmod 755 schedulePlus3/piPrefs.py
   chmod 755 schedulePlus3/piSchedule.py
   chmod 755 schedulePlus3/routerAndMe.py
   chmod 755 schedulePlus3/suntime.py


   #  --- service setup
   if [ -f schedulePlus3/piSchedule.sh ] ; then
     sudo service piSchedule stop 2>/dev/null      # make sure NO schedulePlus is running!

     R='/DIR=/c\DIR='$xDIR/schedulePlus3
     sed -i $R schedulePlus3/piSchedule.sh
   else
     echo -e "\n$br

       NOTE   Missing schedulePlus3 components!
              Check the directory for
              >>schedulePlus3/piSchedule.sh<<
           $e0\n"
     exit 9
   fi

   sudo cp schedulePlus3/piSchedule.sh /etc/init.d/piSchedule
   sudo update-rc.d piSchedule defaults

   port=$(sed 's/, "/\n/g' $xDIR/schedulePlus3/data/piSchedule.prefs.json | egrep "port" | tr -d '":a-zA-Z ')
	addr=$(echo $(hostname -I) | tr -d ' ')

   echo -e "\n

      $ba    Starting 'schedulePlus' now                   $e0

      IMPORTANT If failed ... check with the following commands
      $bg  Run them in the directory 'schedulePlus3'       $e0
      $bw    $ cd $xDIR/schedulePlus3            $e0

        $  service piSchedule status
        $  ./piPrefs.py
        $  ps ax|grep piSchedule

      ... see also log-file:
        $  cat logs/piInfo.log
        $  cat logs/piSystem.log

      $bw With valid results  'piSchedule'  will start.    $e0
      $bw Startup needs a minute, so wait a little before  $e0
      $bw opening 'piSchedule in the browser with:         $e0

      $ba Press Cntrl and mouse point to this link         $e0
               $bb http://$addr:$port $e0
      $ba 'piSchedule' shows up in your browser  $bg Enjoy ;) $e0
          (Eventually you have to reload the page)

    "
   sudo service piSchedule start
   #sudo service piSchedule status

   exit 0
}


function shatest()
{
	s1=$(cat $ZIPP | sha256sum | head -c 64)
	s2=$(wget  -qO- https://neandr.github.io/piSchedule/$ZIPP.sha)
   echo -e "   !!!  ZIP Datei SHA256 Check\n"\
   "    abgerufene Datei  : $s1"
   echo -e ""\
   "    Prüfsumme auf GIT : $s2"
   if [[ ! $s1 == $s2 ]] ; then
   	echo "$br  ZIP Fehler! Checksum nicht übereinstimmend! $e0"
   	exit 1
   fi
}

function getZip()
{
         echo -e "      $ba *** ZIP Auswahl zur Installation  $e0"

         if ! zipps=$(dir -m *.zip | tr '\n' ' '); then
            echo -e "???    No ZIPs found!"
            exit 99
         fi

         IFS=\, read -a zips <<<"$zipps"
         n=0
         for x in "${zips[@]}" ;do
            xDate=$(date -r $x  "+%Y-%m-%d_%H:%M:%S")
            echo "       $n : $xDate   [$x]"
            ((n=n+1))
            done

         read -n 1 -p "      $ba Auswahl für die Installation ?   $e0" No ;
         if [[ $No == ?(-)+([0-9]) && ${zips[$No]} ]] ; then
               ZIPP=$(echo ${zips[$No]} | tr -d ' ')
         else
            echo -e "$br No ZIP selected. Terminating! $e0"
            exit 1
         fi

         echo -e  "\n   ---  ZIP für die Installation:  '$ZIPP'"
         shatest
}

#==============================================

function unzip_2_tmp()
{
   # --- deflate the requested ZIP to a tmp directory ---
   if [ -d tmp/ ] ;  then
      echo -e "!!! ---  '/tmp already exists!"

      read -n 1 -p "*** ---  Overwrite  Y/n? " Qa ;
      echo -e  "\n"
       if [[ ! $Qa == 'Y'  ]] ; then
          echo -e  "\n"
          exit 11
       fi

      rm -R tmp/
   fi

   echo -e "    --- unzipp '$ZIPP' to tmp/ directory "
   unzip -o $ZIPP -d tmp/

 exit 0
}

#==============================================

   # Check not to operate on 'schedulePlus3' directory,
   # should work on it's parent directory!
   if [[ $currentDIR == 'schedulePlus3' ]] ; then
      echo -e "\n!!! ---  Current dir is 'schedulePlus3'"
      echo -e   "!!! ---  Script should not excecuted here!\n"
      exit 100
   fi

   while (( "$#" )); do
     case "$1" in

      --help)
         echo "$H$A"; exit 0
         ;;

      --Z)
         getZip
         shift 1
         ;;

      -l|--libs)
         echo "   ... Bibliotheken laden (Python, Bottle etc ..) ";
         cmd=LibsLoad; shift 1
         ;;

      -i|--install)
         getZip
         echo "   ... System installieren von ZIP"
         cmd=SystemInstall; shift 1
         ;;

      -c|--configure)
         echo "   ... System konfigurieren";
         cmd=SystemConfigure; shift 1
         ;;

      -a|--all)
         echo "   ... Alles ausführen";
         LibsLoad
         SystemInstall
         getZip
         SystemConfigure
         exit 0
         ;;

      *)
         echo "$A"; exit 0
         ;;

     esac
   done
   echo "   ... Aufruf '$cmd' mit ZIP '$ZIPP'"
   $cmd
   exit 0
