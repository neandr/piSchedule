#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
    Copyright (C) 2015 - 2020 gWahl
'''
cVersion = "2020-10-21_14"

import os, subprocess, sys,  json
import socket
from datetime import datetime

def getIPbase():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))
    ipBase = s.getsockname()[0]
    s.close()

    ipBase = ipBase.split('.')
    return "%s.%s.%s" % (ipBase[0],ipBase[1],ipBase[2])

def map_network(ipfirst, iplast):
    # get my IP and compose a base like 192.168.1.xxx
    ipBase = getIPbase()
    print ("IP base:", ipBase)

    results = {}
    other = []
    for i in range(ipfirst, iplast + 1):
        ip = "%s.%s" % (ipBase, str(i))

        try:
            result = (socket.gethostbyaddr(ip))[0]
            results[ip] = result
        except:
            pass
            other.append(ip)

    return results, other


if __name__ == '__main__':
    # set limited range for performance
    ipfirst = 50
    iplast  = 64
    if (len(sys.argv) == 3):
        ipfirst = int(sys.argv[1])
        iplast = int(sys.argv[2])

    print ("localDevices from %s to %s  (%s)" % (ipfirst, iplast, str(datetime.now())[:19]))
    devices, other = map_network(ipfirst, iplast)
    print(json.dumps(devices, indent=3, sort_keys = True))

    # Example for devices:
    '''
      "192.1.11.1": "fritz.box",
      "192.1.11.11": "android-7d6394.fritz.box",
      "192.1.11.36": "TOM-NH&EDC.fritz.box",
      "192.1.11.50": "sonoff-5210.fritz.box",
    '''
