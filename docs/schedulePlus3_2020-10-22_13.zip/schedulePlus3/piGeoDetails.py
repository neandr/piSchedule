#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#  /cVersion/2020-09-06_00/

import urllib.request
import json

from suntime import getSunrise_Sunset

IP_BASE_URL = 'http://ipinfo.io/json'

def piGeoDetails(xP):

    with urllib.request.urlopen(IP_BASE_URL) as response:
        rv = json.loads(response.read())

        if (type(rv) is dict):
            xP['location'] = str(rv['city'].encode('utf-8'))
            xP['longitude'] = str(rv['loc'].split(',')[1])
            xP['latitude'] = str(rv['loc'].split(',')[0])
            xP['locale'] = str(rv['country'])
            xP['status'] = response.getcode()

            rvS =  getSunrise_Sunset(xP['latitude'], xP['longitude'])
            print("from getSunrise_Sunset:", rvS)

            xP['sunset'] = rvS['sunset']
            xP['sunrise'] = rvS['sunrise']

        else:
            xP['status'] = " --- piGeoDetails (ip) failed to deliver geocoordinates for %s" % (response.getcode())

    if rvS['status'] != 0:
        xP['status'] = rvS['status']

    return xP

#---------------------------------
if __name__ == "__main__":
    rv = piGeoDetails({})
    print(rv)
