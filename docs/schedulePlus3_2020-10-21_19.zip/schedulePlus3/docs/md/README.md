<h2 id="pischedule-plus"><em><strong>piSchedule PLUS</strong></em></h2>
<h3 id="hLine2"><em>Heimautomation mit WLAN/Tasmota &nbsp; &nbsp; &nbsp; <small>vers.1.0.1 &nbsp; &nbsp; 2018-12-29</small></em></h3>

<br>

<p><em><strong>piSchedule</strong></em> ist ein exzellentes Werkzeug die Wohnung/Haus Beleuchtung zu schalten. Tagespläne geben die Schaltzeiten an, wobei sich diese am Sonnenauf-/untergang orientieren können. Ebenso lassen sich alle Zeiten durch Zufallswerte variieren. Dies simuliert auch bei Abwesenheit Aktivitäten im Haus.</p>
<p><em><strong>piSchedule</strong></em>  ist ausgelegt für WLAN betriebene Geräte (z.B. Sonoff Schalter etc). Diese Geräte sind heute robust und preiswert. Erfahrungen zeigen, dass sie im Vergleich zu RF-Geräten (433/886Mhz basierend) zuverlässiger arbeiten. Anders als die meisten RF-Geräte bieten die Sonoff-Geräte neben der WLAN Steuerung typischerweise auch manuelle Schaltmöglichkeiten. Auch lässt sich der Status der Geräte jederzeit abfragen, ein weiterer Vorteil für die Anwendungsfunktionalität. Der Betrieb der Sonoff Geräte mit der Tasmota Software läuft lokal im Heimnetz.</p>
<p>Für das Schalten der Geräte, das Einrichten von Tages-/Wochenplänen, deren Betrieb und eine ausführliche Dokumentation ist nur ein Browser auf dem Smartphone, Tablet oder PC erforderlich. <em><strong>piSchedule</strong></em>  selbst wird auf einem RaspberryPi im lokalen Heimnetz zusammen mit den WLAN Geräten betrieben.</p>
<p>Eine detaillierte Beschreibung von <em>Bedienung und Installation</em> ist zu finden in der Dokumentation:</p>
<ul>
<li><a href="scheduleOverview.html">Übersicht/ Benutzung und Installation</a></li>
<li><a href="scheduleEdit.html">Jobs Anlegen und Ändern</a></li>
<li><a href="timeline.html">Timeline / Graphische Übersicht der Schaltzeiten]</a></li>
<li><a href="scheduleExamples.html">Tagesplan/Job Beispiele</a></li>
<li><a href="scheduleFeatures.html">Jobs Eigenschaften</a></li>
</ul>
<p></p><hr>
Zur Installation von <em>piSchedule</em> einfach <a href="schedule7Setup.html">diesen drei Schritten</a> folgen.<p></p>
