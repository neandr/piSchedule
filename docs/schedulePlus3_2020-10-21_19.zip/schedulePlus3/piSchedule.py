#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
    Copyright (C) 2015 - 2020 gWahl
'''
cVersion = "0.8.3.2_2020-10-21_00"


import platform, logging, os, sys, re, signal, shutil  #, traceback
import subprocess, socket

from threading import Thread

from bottle import Bottle, run, static_file, view, template, \
                   get, post, request, debug, \
                   error, abort

import urllib
import urllib.parse

import datetime
from datetime import date
from datetime import datetime
from datetime import timedelta

import time
from time import sleep

from dateutil.parser import *

import json, random, glob

from suntime import getSunrise_Sunset
from sonoffDevices import getDevices

from apscheduler.schedulers.background import BackgroundScheduler

sDIR = os.getcwd()

devices ={}

import piPrefs
xP = piPrefs
from piPrefs import getPrefs

import piLog
from piLog import logInfo, logERR, logSys

from piGeoDetails import piGeoDetails

piStringsJSON = "piStrings.json"
xfileJSON = open(piStringsJSON, 'r')
xStrings = json.loads(xfileJSON.read())

def xS(n):
    lang = str(xP.prefs['locale'])
    return xStrings[lang][n]


app = Bottle()
#app.install(piLog.logBottle)

sched = BackgroundScheduler()


'''
http://stackoverflow.com/questions/7174886/bottle-py-error-routing
'''
@app.route('/errtest')
def errtest():
    #abort("Boo!")
    1/0

@app.route('/err/')
@app.error(500)
@app.error(404)
def errors(error):
    global xP, app

    qString = request.query_string
    errorbody = str(json.dumps(error.body))

    rv = combineKeys(xP.prefs, {'page':'#', 'menuName':xS('mError')})
    #                ( tpl,        keyT,  menu,     keyM,   insertat)
    page = insertTPL('templateErr', rv, 'hamburger', rv, 'hamburger')

    xerr = str(error)
    xerr1 = xerr.replace("\\n", "<br>")
    logSys("../error  >>" + xerr1 + "<<")
    print("../error  >>" + xerr1 + "<<")

    return page.replace('&&errorStatus&&', xerr1)

#===========================================

def prefsSaveJSON():
    #global xP

    try:
        # write a bak copy of current prefs
        f = open((xP.prefs['prefsjson'] + '.bak'), 'w')
        f.write(json.dumps(xP.prefs))
        f.close()
    except:
        pass

    # write new prefs file
    f = open(xP.prefs['prefsjson'], 'w')
    f.write(json.dumps( xP.prefs))
    f.close()


#===============================================
def suntime():
#---------------------------------
#  support Sunrise/Sunset with time values
#  time is calculated for actual day!
    global xP

    if ('latitude' in xP.prefs) and ('longitude' in xP.prefs):

        rvS = getSunrise_Sunset(xP.prefs['latitude'], xP.prefs['longitude'])
        xP.prefs['sunrise'] = rvS['sunrise']
        xP.prefs['sunset'] = rvS['sunset']

        logSys("sunrise:  " + str(xP.prefs['sunrise']) + "   sunset:  " + str(xP.prefs['sunset']))

        prefsSaveJSON()


'''
    Definition in  sonoff.json
    -----------------------------
    "WG": {
      "ip": 53,
      "type": "4ch",
      "state": "off",
      "modes": [
        {
          "dimm": "cm?cmnd=Backlog%20Power2%20off;Power3%20off;power4%20off",
          "main": "cm?cmnd=Backlog%20Power2%20on;Power3%20on;power4%20on"
        }

    Calls
    ---------------------------
    http://192.168.178.83:5005/set?Bad=off
    ../set  message: {'device': 'WG', 'state': 'off'}

    http://192.168.178.83:5005/set?Bad=on;dimm,main
    ../set  message: {'device': 'WG', 'state': 'on', 'modes': 'dimm,main'}


    arg:  'device' , optional parameters 'state', 'modes'
    --------------------------------
    /set?device[=state][;modes]

'''

def send2url(arg):
#---------------------------------
    global xP
    url = ''

    if 'info' in arg:
        if xP.prefs['dayPlanActive'] == 'false':
            mssg = " +++ DayPlan is inactive, device NOT switched! " + str(arg['info'])
            logInfo(mssg)
            log2DayFile(False, mssg)
            return

    # check for sonoff device
    if arg['device'] in xP.sonoffs['devices']:
        device = xP.sonoffs['devices'][arg['device']]

        state2go = ''
        mode2go = ''

        ip = xP.prefs['baseIP'] + str(device['ip'])

        logSys(" ...send2url for device: >>" + str(device) +"<<   arg >>" + str(arg) + "<< " + ip)

        #  'http://' + ip + {command string}
        #  with no {command} string the web page for the device is opened
        url = 'http://' + ip
        powercmd = '/cm?cmnd=power'

        if 'channel' in device:
            pw = str(device['channel'])
        else:
            pw = ''

        # arg
        if 'state' in arg:
            cstate = arg['state']   # state can be number or string like 'state'
            if isinstance(cstate, str) == False:   # state has number
                cstate = 'off'
                if cstate == 1: cstate = 'on'

                cmd2go = powercmd + pw + '%20' + cstate

            ## check if call is for 'optional' and such a dev is valid for 'device' in xP
            if 'optional' in arg and 'optional' in device:
                optionalCmd = device['optional']

                cmd2go = optionalCmd[0][cstate][0]['cmnd']
                logSys("sonoff device call with 'optional' : " + str(optionalCmd)\
                 + " cmd2go >>" + cmd2go +"<<")

            else:
                cstate = arg['state']   # state can be number, 'on'/'off' or string like 'state'
                cmd2go = powercmd + str(pw) + '%20' + cstate

                if arg['state'].lower() == 'state':
                    cmd2go= '/cm?cmnd=status'
                    msg = (" .. sonoff device call with 'status' ")
                    logSys(msg)            #dev

                if arg['state'].lower() == '':
                    msg = (" .. sonoff device call without a 'state!' " + url)
                    logSys(msg)           #dev
                    return [msg]

            url += cmd2go

    with urllib.request.urlopen(url) as response:
        response = json.loads(response.read())

    if 'info' in arg:
        info = str(arg['info'])
    else:
        info = (arg['device'])

    mssg = " ".join((info + " --> " + str(response)).split())
    f_url = "{:44}".format(url)
    logSys("send2url >> " + f_url + " || " + mssg)
    logInfo(mssg)
    log2DayFile(False, mssg)

    return response


# support loading of js/ccs with tpl/html pages
@app.route('/static/<filename>')
def server_static(filename):
    return static_file(filename, root=  'static')
    #return static_file(filename, root= sDIR + '/static')


# get xP.prefs value, example call:  /getxP?version
@app.get('/getxP')
def getxP():
    global xP

    caller = request.fullpath[1:]
    message = urllib.parse.unquote(request.query_string.strip())

    return xP.prefs[message]

#===========================================
'''
   2018-12
   piSchedule now supports Sonoff devices
   '/set' takes the 'device' (and optional 'state' and 'mode')
   and sends it to 'send2url' which builds the approbiated url
   for sonoffs (see there for more details)
'''
# /set?device[=state][;optional]
@app.get('/set')
def set():
    global xP

    caller = request.fullpath[1:]
    message = urllib.parse.unquote(request.query_string.strip())

    #dev print("../set  message >>" + message + "<<")
    #  ../set  message >>Wintergarten=on<<
    #  ../set  message >>Wintergarten=off;optional<<

    '''
        https://www.urldecoder.io/python/
        Küche  #v2  K\\xc3\\xbcche   #v3 K%C3%BCche
    '''

    arg = {}
    arg['device'] = message.split("=")[0]

    arg['state'] = ''
    #arg['optional']

    if len(message.split("=")) > 1:
        cmds = message.split("=")[1].split(";")

        arg['state'] = cmds[0]
        if len(cmds) > 1: arg['optional'] = True

    logSys("/set  message: " + str(arg))
    rv = send2url(arg)

    # set the changed state for devices
    cstate = +(arg['state'] == 'on')
    if 'optional' in arg:
        xP.sonoffs['devices'][arg['device']]['optional'][0]['state'] = cstate
    else:
        xP.sonoffs['devices'][arg['device']]['state'] = cstate
    return ("Device: " + arg['device']  + "  Status: " + str(rv))


@app.route('/weekplan')
def week():
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())
    #logSys("/" + caller + "  >>" + qString + "<<")

    # build 'ini' file menu
    fileList = iniFileMenu('edit')
    fileList += "</li><li role='presentation'><a href='/edit?newSchedule'>" + xS('newSchedule') + "</a></li>"

    fileList1 = iniFileMenu1('weekScheduleSet')

    rv = combineKeys(xP.prefs, {'page':'/weekplan', 'menuName': xS("mEdit"),
        'schedule1': getSchedule4Day('Monday'),
        'schedule2': getSchedule4Day('Tuesday'),
        'schedule3': getSchedule4Day('Wednesday'),
        'schedule4': getSchedule4Day('Thursday'),
        'schedule5': getSchedule4Day('Friday'),
        'schedule6': getSchedule4Day('Saturday'),
        'schedule0': getSchedule4Day('Sunday')
    })

    page = insertTPL('piMain', rv, 'hamburger', rv, 'hamburger')

    page = page.replace('&&iniFileList&&',fileList)
    page = page.replace('&&iniFileList1&&',fileList1)

    return page


def getSchedule4Day(day):
    if 'weekSchedule' in xP.prefs:
        weekSchedule = xP.prefs['weekSchedule']
        if day in weekSchedule:
            return weekSchedule[day]

    return "--"


@app.route('/weekdaySchedule')
def weekdaySchedule():
    weekSchedule = {}
    newSchedule = "--"
    if 'weekSchedule' in xP.prefs:
        weekSchedule = xP.prefs['weekSchedule']
        currentDay = (datetime.now().strftime("%A"))

        if currentDay in weekSchedule:
            newSchedule = weekSchedule[currentDay]

            try:
                open(newSchedule, 'r')
            except:
                newSchedule = "--"

    logSys("weekday schedule is >>" + newSchedule + "<< current day is: " + currentDay)
    return newSchedule


@app.route('/updateWeekdaySchedule')
def updateWeekdaySchedule():
    caller = request.fullpath[1:]
    qString = request.query_string.strip(' ,')
    #dev logSys("/" + caller + "  >>" + qString + "<<")

    schedules = qString.split(',')
    logSys("/setWeekdaySchedule  >>" + str(schedules) + "<<")
    wDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']

    for day in range(0,7):
        xP.prefs['weekSchedule'][wDays[day]] = schedules[day]
    prefsSaveJSON()


@app.route('/schedule')
def getSchedule():
    global xP

    caller = request.fullpath
    if caller != '/schedule':
        qString = ""
    else:
        qString = urllib.parse.unquote(request.query_string.strip())
    logSys("../getSchedule  " + caller[1:] + "  >>" + qString + "<<")

    sched.remove_all_jobs()

    if qString != "":
        aSchedule = qString
    else:
        aSchedule = "Select INI "
        if 'iniFile' in xP.prefs:
            aSchedule = xP.prefs['iniFile']

            renew = True

    xP.switchTime = datetime.now().replace(hour=0,minute=0,second=0,microsecond=0) + timedelta(hours=24)
    #dev log2DayFile(False, ' .. activated Schedule  .. ' + str(xP.switchTime))

    xP.prefs['iniFile'] = aSchedule
    prefsSaveJSON()

    jobLines = jobsRead(aSchedule)
    jobs2Schedule(jobLines)

    cJob = sched.add_job(renewSchedule, 'date', run_date=str(xP.switchTime), id="renew")
    tab = scheduleActive()
    msg = " next SwitchTime  :: " + str(xP.switchTime)

    fileList = iniFileMenu('schedule')

    newsSchedule, newsStatus, newsDate = getNews(caller)

    rv = combineKeys(xP.prefs, {'page':caller,  'menuName': xS('mActualDay'),
        'newsDisplay': newsStatus
    })

    page = insertTPL('piSchedule', rv, 'hamburger', rv, 'hamburger')
    page = page.replace('&&iniFileList&&',fileList)

    hString = str(datetime.now())[:19]
    page = page.replace('&&datetime&&', hString)
    page = page.replace('&&timeTable&&', tab)

    page = page.replace('&&newsDate&&', newsDate)
    return page.replace('&&news&&', newsSchedule)


@app.route('/removeJob')
def removeJob():
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())
    #dev logSys("/" + caller + "  >>" + qString + "<<")

    try :
       sched.remove_job(qString)
    except:
       logInfo("Job may have been removed already")

    page = refreshSchedule()
    return page


@app.route('/dayplan')
@app.route('/reload')
@app.route('/refresh')
def refreshSchedule():
    global xP
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())

    tab = scheduleActive()

    fileList = iniFileMenu('schedule')

    newsSchedule, newsStatus, newsDate = getNews(caller)

    rv = combineKeys(xP.prefs, {'page':'/', 'menuName': xS('mActualDay'),
        'newsDisplay': newsStatus
    })

    page = insertTPL('piSchedule', rv, 'hamburger', rv, 'hamburger')
    page = page.replace('&&iniFileList&&',fileList)

    hString = str(datetime.now())[:19]
    page = page.replace('&&datetime&&', hString)
    page = page.replace('&&timeTable&&', tab)

    page = page.replace('&&newsDate&&', newsDate)
    return page.replace('&&news&&', newsSchedule)


@app.route('/edit')
def edit():
    caller = request.fullpath[1:]
    fileName = urllib.parse.unquote(request.query_string.strip())
    logSys("/" + caller + "  >>" + fileName + "<<")

    rv = combineKeys(xP.prefs, {'page':'/', 'menuName': xS('mEdit')
    })
    page = insertTPL('piEdit', rv, 'hamburger', rv, 'hamburger')

    addEditJob = False
    #fileName  = request.query_string
    if fileName == 'addJob':
       addEditJob = True

    # build the html list of devices
    devices = devicesList()           #TODO ????????????????

    deviceNames = []
    deviceList = []

    for d in devices:
        deviceNames.append(d)
    #                      <a role="menuitem" onclick="changeDevice(this)">Haustür</a>
        deviceList.append('<a role="menuitem" onclick="changeDevice(this)">'+d+'</a>')

    deviceNames.sort()

    deviceList.sort()
    deviceList = ' '.join(deviceList)

    page = page.replace('&&deviceList&&', deviceList)

    # replace date/time string
    hString = str(datetime.now())[:19]
    page = page.replace('&&datetime&&', hString)

    if addEditJob == True:
        page = page.replace('&&JOBS&&',"")         # form
        page = page.replace('&&JOBS1&&',"")        # textarea
        page = page.replace('&&FILE&&',"")

        page = page.replace('&&jobDefEdit&&','display:none')
        page = page.replace('&&jobDefExec&&','display:block')

        page = page.replace('&&displaySchedule&&','display:none')

        page = page.replace('&&jobAdd&&','display:none')
        page = page.replace('&&jobExec&&','display:block')

    else:
        page = page.replace('&&jobDefEdit&&','display:block')
        page = page.replace('&&jobDefExec&&','display:none')

        page = page.replace('&&displaySchedule&&','display:block')

        page = page.replace('&&jobAdd&&','display:block')
        page = page.replace('&&jobExec&&','display:none')

        #  newSchedule
        if fileName == 'newSchedule':
            fileName = 'newDaySchedule.ini'
            f = open(fileName, 'w')
            f.write(' * Define new Schedule')
            f.close()

        if fileName == "" or fileName == None:
            fileName = 'data/piSchedule.ini'

        # read the selected 'ini' file to textbox
        jobLines = jobsReadFile(fileName, setName=False)

        jobList = ""
        jobList1 = ""
        for line in jobLines:
            jobList = jobList + '<option>' + line +'</option>'
            jobList1 = jobList1 + line

        page = page.replace('&&JOBS&&',jobList)   #TODO ????????????
        page = page.replace('&&JOBS1&&',jobList1)

        # set the 'ini' file name
        page = page.replace('&&FILE&&',str(fileName))

    return (page)


@app.route('/addJob')
def addJob():
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())
    logSys("/" + caller + "  >>" + qString + "<<")

    jobs2Schedule ([qString])


@app.route('/fSave')
def fSave():
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())
    logSys("/" + caller + "  >>" + str(qString) + "\n<<")

    qString = json.loads(qString)

    fName = qString[0]['fName']     #file name
    pName = qString[1]['pName']     #placeholder file name
    if fName == "":
      fName = pName

    iniFiles =  glob.glob("*.ini")
    fileList = ""
    for x in iniFiles:
       if fName == x:
           shutil.copy2(fName, fName + '.bak')
           logSys(".. Make .bak Copy of >>" +fName + "<<")

    xjobs = qString[2]['jobs'].replace('|','\n')

    f = open(fName, 'w')
    f.write(xjobs)
    f.close()


@app.get('/fDelete')
def xDelete():
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())
    logSys("/" + caller + "  >>" + str(qString) + "\n<<")

    fName = qString[0]['fName']     #file name
    pName = qString[1]['pName']     #placeholder file name

    if fName == "":
       fName = pName
    os.remove(fName)


@app.route("/removeJobs")
def removeJobs():
    sched.remove_all_jobs()
    return week()


# logs system logs with 'System' or 'Info'
# or log of a weekday
@app.route('/logs')
def logList():
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())
    logSys("/" + caller + "  >>" + qString + "<<")

    if 'System' in qString  or 'Info' in qString:
        qparts = qString.split(".")
        qName = qparts[0]
        qVers = ""
        if len(qparts) == 2:  qVers = '.' + qparts[1]

        #slogFile = xP.prefs['piScheduleHome'] + '/logs/pi' + qName + '.log' + qVers
        slogFile = 'logs/pi' + qName + '.log' + qVers
        try:
            logSys("read Log file >>" + slogFile + "<<")
            aLines = []
            strFile = open(slogFile, 'r')
            logLines = strFile.readlines()

            for Line in logLines:
                cLine = Line.replace('[1;32m','').replace('[1;35m','').replace('[1;36m','').replace('[0m','')
                cLine = cLine.replace(chr(27),"")
                aLines.append(cLine)

        except:
            logERR(True)

        #request.content_type = 'text'
        return  '<br>'.join(aLines)

    elif 'Devices' in qString:
        jDev = json.dumps(xP.sonoffs['devices'], indent=2)

        logSys("Devices >>\n" + jDev + "\n<<")
        return  '<br>Devices<br><pre>' + jDev + '</pre>'

    else:    # log for a weekday

        selectedDay =  qString.strip()

        now = datetime.now()
        today = now.strftime("%A")
        if selectedDay == "":
            selectedDay = today

        fLog = logFile(selectedDay)

        output = []

        try:
            logss = open(fLog, 'r')

            for line in logss:
                output.append('<li>' + line  + '</li>')

            output.sort(reverse=True)
            output = "".join(output)

            output = '<ul>' + str(output) + '</ul>'
            output = str(output)

        except:
           msg = " +++  " + xS("piLogFile") + " "+ fLog + " " + xS("notFound")
           logSys(msg)

        rv = combineKeys(xP.prefs, {'page':caller,  'menuName': xS("dayList"),
            'logList':output,  'today':today
        })

        page = insertTPL('piLogs', rv, 'hamburger', rv, 'hamburger')
        return page.replace("&&currentDay&&", xS(selectedDay))


@app.route('/')
@app.route('/home')
@app.route('/devices')      #@app.route('/scheduleDevices')
def scheduleDevices():
    global xP, devices

    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())

    #dev print(" ~~~~~~~~~~ caller >>" + caller + "<<  ", "::" + qString + "::", " >>" + str(devices['Stecker1/AZ']) + "<<")   #dev

    if caller == 'devices' or devices == {}:
        ipfirst = xP.prefs['ipfirst']
        iplast  = xP.prefs['iplast']

        devices = getDevices(ipfirst,iplast)
        print("\n +#+#+#+  piSchedule caller 'devices'  has ::", devices, "\n\n +#+#+#+ \n")
        xP.sonoffs['devices'] = devices


    logSys(" ** sonoff devices ** " + str(len(devices)) + "\n\n"  + str(devices))   #dev
    #print("#dev *****  piSchedule   has sonoff devices['Stecker1/AZ']:: " + str( devices['Stecker1/AZ']))   #dev

    if devices == {}:
        err = ("../" + caller + "  No devices found! Check sonoffs.json.")
        logSys(err)

        rv = combineKeys(xP.prefs, {'page':caller,  'menuName': xS("mError")})
        page = insertTPL('templateErr', rv, 'hamburger', rv, 'hamburger')
        page = page.replace('&&errorStatus&&', err)
        return page


    # build html page
    deviceNames = []
    allDevices = []

    #<span class="deviceName"  title="##title##" ip="##ip##">##devicename##</span>\

    divblock = '<div class="deviceOp" >\
        <span class="deviceName"  title="##title##" ip="##ip##">\
        <a ip="##http##" onclick="calldevice(this)">##devicename## </a>\
        </span>\
        <input class="toggleDevice" id="toggleDevice" \
            ##checked## ##optional## ##disabled## \
            data-toggle="toggle" data-size="small"\
            data-on="##data-on##" data-off="##data-off##"\
            data-onstyle="##data-onstyle##" \
            data-offstyle="##data-offstyle##" \
            type="checkbox" />\
    </div>'

    for d in devices:
        deviceNames.append(d)

        if devices[d]['type'] != 'switch':          #TODO
            if 'state' in devices[d]:
                dstate = devices[d]['state']

                channel = ""
                if 'channel' in devices[d]:
                    channel = devices[d]['channel']
                    dstate = format(dstate, '08b')[::-1][channel -1]   # [0]

                #print("#dev  ../home  ", d, str(devices[d]), dstate, type(dstate), " channel >>" + str(channel) + "<<")

                cstate = 'checked'
                if (str(dstate) == '0'): cstate = ' '

                labelOFF = '--'
                labelON = '--'

                disabled = 'disabled'
                onstyle = 'default'
                offstyle = 'default'

                if 'active' in devices[d] and (str(devices[d]['active']) == '1'):
                    disabled = ' '
                    onstyle = 'warning'
                    offstyle = 'info'
                    labelOFF = xS('off')
                    labelON = xS('on')

                nextelem = divblock\
                    .replace("##title##", "ip=" + str(devices[d]['ip']))\
                    .replace("##ip##", str(devices[d]['ip']))\
                    .replace("##devicename##", d)\
                    .replace("##checked##", cstate)\
                    .replace("##optional##", "")\
                    .replace("##disabled##", disabled)\
                    .replace("##data-onstyle##", onstyle)\
                    .replace("##data-offstyle##", offstyle)\
                    .replace("##data-on##", labelON)\
                    .replace("##data-off##", labelOFF)\
                    .replace("##http##", str(xP.prefs['baseIP']) + str(devices[d]['ip']))

                allDevices.append(nextelem)

            # add an additional device entry with 'optional' is set in definition
            if 'optional' in devices[d] :
                optional = devices[d]['optional']

                labelOFF = xS(optional[0]['off'][0]['label'])
                labelON = xS(optional[0]['on'][0]['label'])

                cstate = 'checked'
                if (optional[0]['state'] == 1): cstate = ' '

                nextelem = divblock\
                    .replace("##title##", "ip=" + str(devices[d]['ip']))\
                    .replace("##ip##", str(devices[d]['ip']))\
                    .replace("##devicename##", d)\
                    .replace("##checked##", cstate)\
                    .replace("##optional##", "optional")\
                    .replace("##disabled##", disabled)\
                    .replace("##data-onstyle##", onstyle)\
                    .replace("##data-offstyle##", offstyle)\
                    .replace("##data-on##", labelON)\
                    .replace("##data-off##", labelOFF)\
                    .replace("##http##", str(xP.prefs['baseIP']) + str(devices[d]['ip']))

                allDevices.append(nextelem)
    # get first device (alphabetic order)
    deviceNames.sort()
    firstDevice = deviceNames[0]

    # sort devices based on build html code, the 'title'=ip is the sort criteria
    allDevices.sort()
    allDevices = ' '.join(allDevices)
    logSys("\n devices sorted with ip\n" + allDevices)

    rv = combineKeys(xP.prefs, {'page':caller,  'menuName': xS("overviewTitle")})

    page = insertTPL('scheduleDevices', rv, 'hamburger', rv, 'hamburger')
    page = page.replace('&&allDevices&&', allDevices)
    page = page.replace('&&cVersion&&', cVersion)

    return page


'''
   Support GeoData retrieving             2019-01-25
'''
@app.route('/geodetails')
def geodetails():
    global xP
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())

    logSys("/" + caller + " GeoDetails: "  + str(qString))
    rv = combineKeys(xP.prefs, {'page':caller,  'menuName': 'GeoDetails'
    })
    return insertTPL('geoDetails', rv, 'hamburger', rv, 'hamburger')

#======================================================
'''
   Timeline for Actual time settings             2017-01-17_18
'''
def scheduleList():
#---------------------------------
    output = []

    #sON = xS("on")    #'AN'
    #sOFF = xS("off")  #'AUS'

    aJobs = sched.get_jobs()
    if len(aJobs) == 0:
        pass

    else:
        n = 0
        cDay = datetime.now().day
        while n < len(sched.get_jobs()):

            schTime = str(sched.get_jobs()[n].trigger).replace("date", '')

            sTime = (sched.get_jobs()[n].trigger).run_date
            if sTime.day != cDay:
                schTime = '> ' + s2(sTime.hour)+ ":" + s2(sTime.minute) + ":" + s2(sTime.second)
            else:
                schTime = s2(sTime.hour) + ":" + s2(sTime.minute) + ":" + s2(sTime.second)

            if (sched.get_jobs()[n].name) == 'send2url':
                info = str(sched.get_jobs()[n].args[0]['info'])
            else:
                info = sched.get_jobs()[n].name

            if  len(info.split(' off ')) == 2:
                onOff = 'off'   #sOFF
                cinfo = info.split(' off ')

            if  len(info.split(' on ')) == 2:
                onOff = 'on'   #sON
                cinfo = info.split(' on ')

            if (sched.get_jobs()[n].id) == 'renew':
                button = ""
                cinfo = {}
                cinfo[0] = "renew"
                cinfo[1] = ""
                onOff = ""

            newAppend = ( str(cinfo[0].strip()) + "; "
                         + schTime + "; "
                         + onOff + "; "
                         + str(sched.get_jobs()[n].id) + "; "
                         + cinfo[1]
                         )

            output.append(newAppend)
            n += 1

        output.sort()
    return (output)


@app.route('/timeline')
def timelinePlan():
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())
    logSys("/" + caller + "  >>" + str(qString) + "<<")

    rv = combineKeys(xP.prefs, {'page':'/timeline', 'menuName': xS('mTimelinePlan')
    })

    page = insertTPL('piTimeLine', rv, 'hamburger', rv, 'hamburger')
    page = page.replace('&&title&&','Timeline  DE')
    page = page.replace('&&sunrise&&',(xP.prefs['sunrise'])[11:])
    page = page.replace('&&sunset&&',(xP.prefs['sunset'])[11:])

    startTime = "10:00:00"
    if 'timelineStart' in xP.prefs :
        startTime = xP.prefs['timelineStart']

    endTime = "24:00:00"
    if 'timelineEnd' in xP.prefs :
        endTime = xP.prefs['timelineEnd']

    page = page.replace('&&endTime&&', endTime)
    page = page.replace('&&startTime&&', startTime)

    fileName = xP.prefs['iniFile']
    jobsList = jobsRead(fileName)

    jobs = ""
    nJ = len(jobsList)

    ni=0
    while ni < nJ:
        if jobsList[ni] != "\n":
            jobs += jobsList[ni] +  "||"
        ni += 1

    page = page.replace('&&FILE&&',str(fileName))
    page = page.replace("&&jobLines&&", jobs.replace("\n",""))

    # build the html list of devices
    #<a role="menuitem" onclick="changeDevice(this)">Haustür</a>
    devices = devicesList()     #TODO ?????????????????

    logSys("/" + caller + " sonoff devices: " + str(devices))

    if devices == {}:
        err = ("..'/timeline'  No devices found! Check sonoff.json.")
        logSys(err)

        page = insertTPL('templateErr', rv, 'hamburger', rv, 'hamburger')
        page = page.replace('&&errorStatus&&', err)

        return page

    deviceNames = []
    deviceList = []

    for d in devices:
        if 'state' in devices[d]:
            deviceNames.append(d)
            deviceList.append('<a role="menuitem" onclick="changeDevice(this)">'+d+'</a>')

    deviceNames.sort()
    firstDevice = deviceNames[0]

    deviceList.sort()
    deviceList = ' '.join(deviceList)

    if qString != "":
        firstDevice = qString

    firstDeviceStatus = str(devices[firstDevice]['state'])

    page = page.replace('&&deviceList&&', deviceList)
    page = page.replace('&&firstDevice&&', firstDevice)
    page = page.replace('&&firstDeviceStatus&&', firstDeviceStatus.lower())

    # not used with timelineSchedule
    page = page.replace('&&scheduleLines&&', "")

    return page


@app.route('/timelineSchedule')
def timelineSchedule():
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())
    logSys("/" + caller + "  >>" + str(qString) + "<<")

    rv = combineKeys(xP.prefs, {'page':'/timelineSchedule', 'menuName': xS('mTimelineSchedule')
    })

    page = insertTPL('piTimeLine', rv, 'hamburger', rv, 'hamburger')
    page = page.replace('&&sunrise&&',(xP.prefs['sunrise'])[11:])
    page = page.replace('&&sunset&&',(xP.prefs['sunset'])[11:])

    startTime = "10:00:00"
    if 'timelineStart' in xP.prefs :
        startTime = xP.prefs['timelineStart']

    endTime = "24:00:00"
    if 'timelineEnd' in xP.prefs :
        endTime = xP.prefs['timelineEnd']

    page = page.replace('&&endTime&&', endTime)
    page = page.replace('&&startTime&&', startTime)


    fileName = xP.prefs['iniFile']
    page = page.replace('&&FILE&&',str(fileName))

    devices = devicesList()             #TODO  ????????????????

    deviceNames = []
    deviceList = []

    for d in devices:
        deviceNames.append(d)

        if 'state' in devices[d]:
            deviceList.append(d + ',' + str(devices[d]['state']))

    deviceNames.sort()

    deviceList.sort()
    deviceList = ';'.join(deviceList)

    page = page.replace('&&deviceList&&', deviceList)

    # not used with timelineSchedule
    page = page.replace('&&firstDevice&&', "")
    page = page.replace('&&firstDeviceStatus&&', "")
    page = page.replace('&&jobLines&&', "")

    currentPlan = scheduleList()

    for job in currentPlan:
        items = job.split(";")
        try:
            logSys(".. cPlan item:" + items[0] + " :: " +items[1]  + " :: " +items[2]+ " :: " +items[3]
                + " state:" + devices[items[0]]['state'])
        except:
           logSys(".. cPlan item:" + items[0] + " :: " +items[1]  + " :: " +items[2]+ " :: " +items[3])

        # cPlan item:Stehlampe ::  21:59:41 ::  AN ::  7341146
    page = page.replace('&&scheduleLines&&', str(currentPlan))

    return page


#-------------------------------------------

# following calls will set a specific prefs item and
#   return updated /schedule page
@app.route('/timelineEnd')
@app.route('/timelineStart')
@app.route('/news')
@app.route('/iniFile')
@app.route('/locale')
@app.route('/dayPlanActive')
def setPrefs():
    caller = request.fullpath[1:]
    qString = (urllib.parse.unquote(request.query_string.strip())).replace('%20',' ')
    logSys("/" + caller + "  >>" + qString + "<<", '36')  #36mCyan"

    if qString != "":

        if caller in xP.prefs:
            xP.prefs[caller] = qString
            prefsSaveJSON()

            return (xP.prefs)
        else:
            return ("** Unknown item in xP.prefs! **")



@app.route('/geoCoordinates')
@app.route('/suntimes')
def setgeo():
    caller = request.fullpath[1:]
    qString = (urllib.parse.unquote(request.query_string.strip())).replace('%20',' ')   #dev
    logSys("/" + caller + "  >>" + qString + "<<", '36')  #36mCyan"

    if caller == 'geoCoordinates':
        xP.prefs['latitude'] = qString.split(',')[0]
        xP.prefs['longitude'] = qString.split(',')[1]

    if caller == 'suntimes':
        xP.prefs['sunrise'] = qString.split(',')[0]
        xP.prefs['sunset'] = qString.split(',')[1]


@app.route('/prefs')
def listPrefs():
    global devices

    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())
    logSys("/" + caller + "  >>" + qString + "<<", '36')  #36mCyan"

    #devices = devicesList()

    #showPrefs = json.dumps(xP.prefs, sort_keys=True, indent=3)
    #showSonoffs = json.dumps(devices, sort_keys=True, indent=3)
    showPrefs = json.dumps(xP.prefs, indent=3)
    showSonoffs = json.dumps(devices, indent=3)
    showPrefs = (showPrefs + "<br><br>" + showSonoffs).replace(",",",<br> &nbsp; &nbsp; ")
    #showPrefs = (showPrefs + "<br><br>" + showSonoffs)

    return [showPrefs]


@app.route('/newsDate')
def setNewsDate():
    caller = request.fullpath[1:]
    message = urllib.parse.unquote(request.query_string.strip())
    logInfo("/" + caller + "  >>" + str(message) + "<<")

    xP.prefs['newsDate'] = str(datetime.now())[:10]


#=================================================
@app.route('/about')
def about():
    caller = request.fullpath[1:]
    message = urllib.parse.unquote(request.query_string.strip())

    language = str(xP.prefs['locale'])
    xP.prefs['platform'] = platform.uname()[1] + " -- " + str(platform.platform()).replace("'","")

    logSys("/" + caller + "  >>" + str(platform.uname()) + "<<  >>" + language + "<<")
    if language == 'EN':
        deDisplay = 'none'
        enDisplay = 'block'

    if language == 'DE':
        deDisplay = 'block'
        enDisplay = 'none'

    today = datetime.now().strftime("%x")

    newsSchedule, newsStatus, newsDate = getNews(caller)

    rv = combineKeys(xP.prefs, {'page':'/about', 'menuName':xS("mAbout"),
        'deDisplay': deDisplay,
        'enDisplay': enDisplay,
        'today': today,
        'newsDisplay': newsStatus,
        'newsDate': newsDate
    })

    page = insertTPL('piAbout', rv, 'hamburger', rv, 'hamburger')
    page = page.replace('&&news&&', newsSchedule)
    return page


#-------------------------------------------
@app.route('/close')
def close():
    global piScheduleStatus

    piScheduleStatus = False
    time.sleep(8)

    caller = request.fullpath[1:]
    message = urllib.parse.unquote(request.query_string.strip())
    logInfo(caller)

    os.kill(os.getpid(), signal.SIGTERM)


#===========================================
def combineKeys(rv1, rv2):
    return {**rv1, **rv2}

def templateSetup(templ, rv):
    locale = str(xP.prefs['locale'])
    keys = combineKeys(rv, xStrings[locale])

    thisTemplate = template(templ, keys)

    # special formatting character replacement
    return thisTemplate.replace("{P}","<br>").replace("{i}","<i>").replace("{/i}","</i>")

# Support to insert a sub-page.tpl (like 'menu') into
# a main.tpl (like 'tpl') at a key {{hamburger}}.
# Both templates can use their own keys.
def insertTPL(tpl, keyT, menu, keyM, insertAt):
    subtpl = templateSetup(menu, keyM)
    rv = combineKeys(keyT, {insertAt:subtpl})

    return templateSetup(tpl, rv)


#=============================================

def getNews(caller):
# ---------------------------
    response = ""
    newsStatus = ""
    newsDate = ""

    print(" .... getNews")

    try:
        url = xP.prefs['news']

        with urllib.request.urlopen(url) as response:
            response = response.read()

        response = response.decode('utf-8')     #TODO ??????????????

        newsStatus = "color: gray;" #'display:none'
        nLine = 0
        lines = response.split('\n')
        for line in lines:
            if nLine == 0:
                # first line holds 'newsDate', compare with 'newsDate' in prefs
                # and switch color of link
                newsDate = lines[nLine].strip()
                if 'newsDate' in xP.prefs and newsDate > xP.prefs['newsDate']:
                    newsStatus = "color: blue;"

                lines[nLine] = "<div align='right' style=\'margin-bottom:-5px;padding-right: 100px;\'> \
                        <b>" + lines[nLine] + "</b></div><p style='margin:0;padding-left: 30px;padding-right: 100px;'>"

            if lines[nLine][0:3] == "** " :
                lines[nLine] = "<b> " + lines[nLine][3:] + "</b>"

            if lines[nLine][0:3] == "   " :
                lines[nLine] = "<span style='margin-left:10px;'>" + lines[nLine][3:] + "</span>"

            if lines[nLine][0:3] == "|| " :
                lines[nLine] = "<blockquote style='margin-top:-10px;margin-left:35px;'><small><tt>" + lines[nLine][3:] + "</tt></small></blockquote>"

            if lines[nLine][0:3] == "__ ":
                lines[nLine] = "<u> " + lines[nLine][3:] + "</u>"

            if lines[nLine][0:3] == "===":
                lines[nLine] = "</p><hr style='margin-top: -5px; margin-bottom: 0px;'><p style='padding-left: 50px;padding-right: 100px;'>"

            cLine = lines[nLine]
            linkA = cLine.find(" [")
            if linkA != -1:
                linkM = cLine.find("](", linkA)
                if linkM != -1:
                   linkE = cLine.find(")", linkM)
                   if linkE != -1:
                       linkDesc = cLine[(linkA+2):linkM]
                       link =     cLine[(linkM+2):linkE]
                       cLink =  "<a href='" + link + "'>" + linkDesc + "</a>"
                       lines[nLine] = lines[nLine].replace(lines[nLine][(linkA+1):(linkE+1)], cLink)

            lines[nLine] = lines[nLine].replace("   ", "")
            nLine = nLine +1

        response = "<br>".join(lines)

    except Exception as e:
        logSys("getNews failed for: " + url + "  %s " % str(e) )
        print("getNews failed for: " + url + "  %s " % str(e) )

    logInfo("**** newsDate   >>" + str(newsDate) + "<< " + caller)

    return  response, newsStatus, newsDate


def devicesList():
    global xP

    devices = xP.sonoffs['devices']
    url = 'http://' + xP.prefs['baseIP']

    for device in devices:
        cmd = url + str(devices[device]['ip']) +'/cm?cmnd=status'
        response = ""
        try:
            request = urllib.request(cmd)
            response = urllib.urlopen(request).read()

            devices[device]['state'] = response['Status']['Power']
            #devices[device]['active'] = 'true'
        except:
            pass

    return devices


def deviceScan():
    global devices

    devices = xP.sonoffs['devices']
    url = 'http://' + xP.prefs['baseIP']

    for device in devices:
        ip = str(devices[device]['ip'])
        cmd0 = url + ip
        print(" in deviceScan   cmd0:", cmd0, ip)

        response = ""
        with urllib.request.urlopen(cmd0 +'/cm?cmnd=status') as response:
            _status = json.loads(response.read())

        with urllib.request.urlopen(cmd0 + '/cm?cmnd=module',) as response:
            _module = json.loads(response.read())

        '''
         _status ::
         {'Status': {'Module': 1, 'FriendlyName': ['Pumpe'],
          'Topic': 'sonoff',
          'ButtonTopic': '0', 'Power': 1, 'PowerOnState': 3, 'LedState': 1, 'SaveData': 1,
          'SaveState': 1, 'SwitchTopic': '0', 'SwitchMode': [0, 0, 0, 0, 0, 0, 0, 0],
          'ButtonRetain': 0, 'SwitchRetain': 0, 'SensorRetain': 0, 'PowerRetain': 0}}
        '''

        xP.sonoffs['devices'][device]['state'] = _status['Status']['Power']
        xP.sonoffs['devices'][device]['FriendlyName'] = _status['Status']['FriendlyName']
        xP.sonoffs['devices'][device]['module'] = _module

    logSys('\n\n' + str(datetime.now()) + ' ---->>> sonoff devices scanned\n' + json.dumps(devices, indent=3) + "\n<<----\n")
    return devices


def iniFileMenu(mode):
    # build 'ini' file menu
    fHtml = '<li role="presentation"><a href="/' + mode + '?&&fName&&">&&fName&&</a></li>'

    iniFiles =  sorted(glob.glob("data/*.ini"))

    fileList = ""  #<a role='menuitem' >&nbsp;&nbsp; " + xS('editSchedule') + "... </a>"
    for x in iniFiles:
       fileList += fHtml.replace('&&fName&&',x)

    return fileList

def iniFileMenu1(mode):
    # build 'ini' file menu
    fHtml = '<a id="test1" style="cursor:pointer;" onclick="' + mode + '(this)">&&fName&&</a>'

    iniFiles =  sorted(glob.glob("data/*.ini"))

    fileList = '<a id="test2" style="cursor:pointer;" onclick="' + mode + '(this)">--</a>'
    for x in iniFiles:
       fileList += fHtml.replace('&&fName&&',x)

    return fileList


def jobsReadFile(message, setName=True):
#---------------------------------------
    jobLines = ""
    if message != None:
        try:
            if '.ini' in message:
                jobFile = open(message, 'r')
                jobLines = jobFile.readlines()
                if setName == True:
                    xP.prefs['iniFile'] = message
        except:
            pass

    return jobLines


def jobsRead(cIniFile = 'data/piSchedule.ini'):
    if cIniFile == "":
        cIniFile = 'data/piSchedule.ini'

    jobLines = ""
    try:
        msg = "read INI Jobs file >>" + cIniFile + "<<"

        jobLines = jobsReadFile(cIniFile)
        logSys(msg + "\n" + str(jobLines))
        logInfo(msg)

    except:
        pass            #TODO if fails get 'piSchedule.ini' or initialize it
        logSys("+++++ trace   jobsRead failed .... >>" + jobLines + "<<")    #dev
        logERR(False)

    return jobLines


def jobs2Schedule(jobLines):
#---------------------------------
    ''' lampe2; on
        lampe2; on,22:50;off,+:10
        lampe2; on,+:02;  off,+:03:00
          * text/comment
        lampe2; on,+:02;off,+:03:00
        lampe2; on,+01:02,sunrise;off,-01:30,sunset;on,~:10,18:00;off,~:15,21:05
    '''
    global xP

    for cJobs in jobLines:
        cJobs = cJobs.strip()

        # strip out empty or comment lines
        if len(cJobs) == 0 or cJobs[0] == '*':
            continue

        cJob = cJobs.split(";")
        cJobLen = len(cJob)

        if cJobLen >  1 :
            actualDevice = cJob[0].strip().replace("%20", "")

        now = datetime.now()

        n = 1
        while n < (cJobLen):
            currentSwitch = cJob[n].strip().replace("%20", "")

            # inkrement now to ensure to have a 1 sec delta to the previous switchtime
            now =  now + timedelta(hours=0, minutes=0, seconds=n)
            now, currentJob, xP.switchTime = scheduleSet(now, actualDevice, currentSwitch, xP.switchTime)
            n += 1
    return


def scheduleSet(onTime, actualDevice, currentSwitch, switchTime):
#---------------------------------
    ''' lampe2; on,+:02
        actualDevice=    lampe2;
        currentSwitch=   on,+:02
    '''

    actualSwitch = currentSwitch.strip().replace("%20", "").split(",")

    logInfo("job -->> " + str(actualDevice) + ": " + str(actualSwitch))

    aswitch = actualSwitch
    if ('on' in aswitch or 'off' in aswitch) == False:
        return xS("noState")  # ERROR: no on/off

    # piSchedule direct on/off switching
    if len(actualSwitch) == 1:
        arg = {}
        arg['device'] = actualDevice
        arg['state'] = actualSwitch
        #arg['info'] = '{0:12} {1:15}'.format(actualDevice[0:12], currentSwitch.replace(',', ' '))
        arg['info'] = '{0:14} {1:15}'.format(actualDevice, currentSwitch.replace(',', ' '))

        send2url(arg)
        #sleep(2)  # for testing .. delay between directly switching
        jmsg = [str(onTime)[0:19], actualDevice, currentSwitch]
        return [onTime, jmsg, switchTime]

    xTime = onTime
    deltaTime = "*"

    # xTime = '2014-04-17 22:06:00'  NEED secs, even if ':00'

    for nSwitch in actualSwitch:
        nSwitch = nSwitch.strip()

        # have dateTime or sunrise or sunset
        if nSwitch == 'sunrise':
            #v2  xTime = parse(xP.prefs['sunrise'])
            xTime = parse(xP.prefs['sunrise'])    #v3
        elif nSwitch == 'sunset':
            #v2  xTime = parse(xP.prefs['sunset'])
            xTime = parse(xP.prefs['sunset'])   #v3

        # --- use deltaTime
        # '+' add or '-' subtract time value
        # '~' add or '~-' subtract 'random' time value
        elif nSwitch[0] == '+' or nSwitch[0] == "-"  \
         or nSwitch[0] == "~":
            h = 0
            min = 0
            sec = 0

            random_subtract = False
            if nSwitch[0:2] == "~-":  #  subtract random time
                random_subtract = True
                delta = nSwitch[2:]
            else:
                delta = nSwitch[1:]

            xDelta = delta.split(":")
            nDelta = len(xDelta)
            if nDelta >= 1:
                h = 0 if xDelta[0] == '' else int(xDelta[0])
            if nDelta >= 2:
                min = 0 if xDelta[1] == '' else int(xDelta[1])
            if nDelta == 3:
                sec = 0 if xDelta[2] == '' else int(xDelta[2])
            deltaTime = timedelta(hours=h, minutes=min, seconds=sec)

            if nSwitch[0] == '+':  # # add timedelta
                #logInfo("  delta + : " + nSwitch)
                xTime = xTime + deltaTime           #++++++++

            if nSwitch[0] == '-':  # # substract timedelta
                #logInfo("  delta - : " + nSwitch)
                deltaTime = -deltaTime
                xTime = xTime + deltaTime           #++++++++

            elif nSwitch[0] == '~':  # # add random minutes
                rMin = h * 60 + min
                if random_subtract:
                    deltaTime = -timedelta(minutes=random.randrange(rMin))
                else:
                    deltaTime = timedelta(minutes=random.randrange(rMin))

                #logInfo("  random  : " + nSwitch + " --> deltaTime  : " + str(deltaTime))
                xTime = xTime + deltaTime           #++++++++

                # ... use deltaTime

        elif nSwitch == 'on' or nSwitch == "off" or nSwitch == "time" :
                pass
        else:
            # check for absolute time not to be 24:00 and any other unknown format
            try:
                if (nSwitch == "24:00"):
                    nSwitch = "23:59"
                xTime = parse(nSwitch)
            except:
                nSwitch = 'err:' + str(nSwitch)
                logInfo(xS("unknownString") + ">>" + nSwitch + "<<")

        logInfo("nSwitch >>" + str(nSwitch) +"<<   xTime >>" + str(xTime) + "<<")

    xTime = xTime + timedelta(seconds=random.randrange(60))

    # remember 'on' state time
    wasOnTime = onTime
    onTime = xTime
    jmsg = []
    stateOnOff = 'on'

    # check if xTime is before actual time
    if (xTime < datetime.now()):

        logInfo("SKIP: " + str(xTime)[0:19] + "  :: "
            + currentSwitch.strip() + "   +++ " + xS("beforeTime") + " +++ \n")
    else:
        logInfo("Job set: " + str(xTime)[0:19] + "  :: "
            + actualDevice + "  :: " + currentSwitch + "\n")

        jmsg = [str(xTime)[0:19], actualDevice, currentSwitch]
        jobName = str(int(time.time() * 1000))[6:]

        info = ('{0:14} {1:15} '.format(actualDevice, currentSwitch.replace(',', ' ')))

        if 'off' in actualSwitch:
            info = info + "  (on: " + str(wasOnTime)[11:16] + ")"
            stateOnOff = 'off'

        cJob = (sched.add_job(send2url, 'date', run_date=str(xTime), \
            args=[{'info':info, 'device':actualDevice, 'state':stateOnOff}], \
            id=jobName))

        if xTime > switchTime:
            switchTime = xTime

    return [onTime, jmsg, switchTime]


def scheduleActive():
#---------------------------------
    tablebody = '<table id="scheduleTable" class="table table-striped table-bordered"><tbody>'
    output = []

    button = ("  <button class='btn btn-default btn-sm dropdown-toggle  pull-right'"
       + "id='removeJob' onclick='action(this)' title='" + xS('removeJob') + "'"
       + " type='button'>"
       + " <img title='Help' src='/static/gminus.png' style='width:18px'>"
       + "</button>")

    sON = xS("on")    #'AN'
    sOFF = xS("off")  #'AUS'

    aJobs = len(sched.get_jobs())

    if aJobs == 0:
        pass
    else:
        n = 0
        cDay = datetime.now().day
        while n < aJobs:

            schTime = str(sched.get_jobs()[n].trigger).replace("date", '')
            sTime = (sched.get_jobs()[n].trigger).run_date
            if sTime.day != cDay:
                schTime = '> ' + s2(sTime.hour)+ ":" + s2(sTime.minute) + ":" + s2(sTime.second)
            else:
                schTime = s2(sTime.hour) + ":" + s2(sTime.minute) + ":" + s2(sTime.second)

            if (sched.get_jobs()[n].name) == 'send2url':
                info = str(sched.get_jobs()[n].args[0]['info'])
            else:
                info = sched.get_jobs()[n].name

            if  len(info.split(' off ')) == 2:
                onOff = sOFF
                cinfo = info.split(' off ')

            if  len(info.split(' on ')) == 2:
                onOff = sON
                cinfo = info.split(' on ')

            if (sched.get_jobs()[n].id) == 'renew':
                button = ""
                cinfo = {}
                cinfo[0] = "renew"
                cinfo[1] = ""
                onOff = ""

            newAppend = ("<tr><td> " + schTime + "</td>"
                         + "<td>" + cinfo[0] + "</td>"
                         + "<td>" + onOff + "</td>"
                         + "<td  id='" + str(sched.get_jobs()[n].id)+ "'> " + cinfo[1]
                         + button + "</td></tr> ")

            output.append(newAppend)
            n += 1

        output.sort()

    return (tablebody + ' '.join(output) + '</tbody></table>')


# renew reads jobs back from Scheduler (sched) to update the current
# job list to be executed
def renewSchedule():
    if 'iniFile' in xP.prefs:
        daySchedule = weekdaySchedule()
        if daySchedule != "--":
            xP.prefs['iniFile'] = daySchedule

        aSchedule = xP.prefs['iniFile']

        sched.remove_all_jobs()
        log2DayFile(True, 'renew Schedule')

        xP.switchTime = datetime.now().replace(hour=0,minute=0,second=0,microsecond=0)+  timedelta(hours=24)

        suntime()
        jobLines = jobsRead(aSchedule)
        jobs2Schedule(jobLines)
        tab = scheduleActive()
        cJob = sched.add_job(renewSchedule, 'date', run_date=str(xP.switchTime), id="renew")
        msg = "renew Schedule  next Switch Time   " + str(xP.switchTime)[:19] + " lang:" + str(xP.prefs['locale'])
        logSys(msg)
        log2DayFile(True, msg)
        prefsSaveJSON()
    else:
        logSys("rewnewSchedule    ERROR ! ")
        logERR(False)


#================================================
def s2(v):
    if v < 10:
        return '0'+str(v)
    return str(v)


def log2DayFile(new=False, info='xnewx'):
    sDay = datetime.now()
    logF = logFile(sDay.strftime("%A"))

    if new == True:
        logInfo("new log day file: " + logF + " " + datetime.now().strftime("%Y-%m-%d"))
        try:
            os.remove(logF)
        except:
            pass

    now = datetime.now()
    f = open(logF, 'a')

    f.write(str(now)[0:19] + " : " + info + "\n")
    f.close()


def logFile(sDay):
    return sDay + '.log'


def piScheduleMonitor(count):
    global xP, piScheduleStatus, devices

    test = 1
    print("piScheduleMonitor", count, test)
    logSys(" .. piScheduleMonitor  ../deviceScan start ")
    ipfirst = xP.prefs['ipfirst']
    iplast = xP.prefs['iplast']

    while piScheduleStatus:
        time.sleep(10)
        devices = getDevices(ipfirst,iplast)

        #dev  print("piScheduleMonitor  updated " + str(datetime.now())[:19], "\n -->", str(devices['Stecker1/AZ']))

piScheduleStatus = True

#===========================================
def main():
    global xP, piScheduleStatus, devices

    msg = '\n\n    ________Started   piSchedule  (main)________   (' + cVersion + ')'

    logSys(msg)
    logInfo(msg)

    debug(mode=False)        # Bottle debug mode <<<<<<<<<<<<<<<<<

    xP.switchTime = datetime.now().replace(hour=0,minute=0,second=0,microsecond=0)+  timedelta(hours=24)
    xP.prefs, xP.sonoffs = getPrefs()

    print("  *** starting with ipfirst,iplast::", xP.prefs['ipfirst'], xP.prefs['iplast'])

    ipfirst = xP.prefs['ipfirst']
    iplast  = xP.prefs['iplast']

    devices = getDevices(ipfirst,iplast)
    xP.sonoffs['devices'] = devices

    logInfo("  *** prefs  List \n" + str(xP.prefs))
    logInfo("  *** sonoff List \n" + str(devices))
    logSys("\n\n  *** piSchedule startup 'devices' List \n" + str(devices) + "\n\n")

    sched.start()    # start the Monitor scheduler

    i = 0
    t = Thread(target=piScheduleMonitor, args=(i,))
    t.start()

    renewSchedule()  # if iniFile is set, load jobList of it

    try:
       # starting bottle with web page
       print("\n  *** piSchedule started! Using Devices '%s .. %s' *** " % (ipfirst, iplast))
       print("  *** Terminate with 'http://%s:%s/close'  *** \n" % (xP.prefs['server'], xP.prefs['port']) )
       app.run(host = xP.prefs['server'], port = xP.prefs['port'], reloader=False)
    except:
        logSys(  "  ***  'bottle' server starting failed!        *** " \
               "\n  ***   Check with 'ps ax|grep piSchedule'     *** " \
               "\n  ***   to kill a running piSchedule process!  ***\n\n")


#-------------------------------------------
if __name__ == '__main__':
    rcode = main()
