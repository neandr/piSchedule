#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''
    Copyright (C) 2015 -2019 gWahl
'''
#  /cVersion/2019-01-05_01/

import piPrefs
xP = piPrefs


import logging, traceback, os, signal
import logging.handlers

from functools import wraps
from datetime import datetime

from bottle import request, response
import sys


# create formatter and add it to the handlers
#formatter = logging.Formatter('#%(process)s %(asctime)s - %(message)s\033[0m',"%H:%M:%S")
formatter =  logging.Formatter('%(asctime)s -- %(message)s',"%H:%M:%S")

fh = logging.handlers.RotatingFileHandler(
              xP.logSysName, maxBytes=50000, backupCount=2)
fh.setFormatter(formatter)


#-----------------------------
# Logger for 'error' messages
# Detail log info goes to piSystem.log
def logERR(close):
    stack = traceback.extract_stack()
    filename, codeline, funcName, text = stack[-3]

    sFuncName = (funcName + '   ERROR! ').ljust(21," ")
    loggerX.error("\033[1;31m{0} \033[0m #{1} \n{2}".format(sFuncName, codeline, traceback.format_exc().replace("\n    ", "   ")))

    if close == True:
        logInfo("*** Error! Terminated, see piSystem.log for details. ***")
        sys.exit(99)

loggerX = logging.getLogger('cPiS')
loggerX.setLevel(logging.INFO)  # normal setting at which level logging starts

fh = logging.handlers.RotatingFileHandler(
        xP.logSysName, maxBytes=50000, backupCount=2)
fh.setFormatter(formatter)
loggerX.addHandler(fh)

#----------------
# Logger for System Messages goes to piSystem.log
def logSys(msg, color='35'):   # magenta
    loggerS.info(logString(msg, color, True))

loggerS = logging.getLogger('cSys')
loggerS.setLevel(logging.INFO)  # normal setting at which level logging starts

fh = logging.handlers.RotatingFileHandler(
        xP.logSysName, maxBytes=50000, backupCount=2)
fh.setFormatter(formatter)
loggerS.addHandler(fh)


#----------------
# Logger for Info Messages
def logInfo(msg, color='32'):   # green
    loggerI.info(logString(msg, color, False))

loggerI = logging.getLogger('cInfo')
loggerI.setLevel(logging.INFO)  # normal setting at which level logging starts

fh = logging.handlers.RotatingFileHandler(
        xP.logInfoName, maxBytes=50000, backupCount=2)
fh.setFormatter(formatter)
loggerI.addHandler(fh)


#----------------
def logString(msg, color, source):
    stack = traceback.extract_stack()
    filename, codeline, funcName, text = stack[-3]
    filename1, codeline1, funcName1, text1 = stack[-4]

    head, tail = os.path.split(filename)
    root, ext = os.path.splitext(tail)

    if funcName == "_logBottle":
        funcName = "bottle"

    if source == True:
        s = funcName1 + " #" + str(codeline1) + " --> " \
          + funcName  + " #" + str(codeline)
        s1 = "{:42}".format(s)
    else:
        s = (funcName + " #" + str(codeline)).ljust(22," ")
        s1 = "{:20}".format(s)

    #return ("\033[1;"+ str(color) + "m" + s1 +"\033[0m " + msg)
    return (s1 + " " + msg)

def main():
    pass
