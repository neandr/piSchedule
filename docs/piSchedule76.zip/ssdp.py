#!/usr/bin/python3
#
#   Copyright (C) 2015 pilino1234
#
#   This file is part of pylight.
#
#   pylight is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   pylight is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
"""
Short and simple SSDP discovery library.

Takes the ssdp service name as a string
Returns the IP and Port of the pilight daemon

"""
import socket
import re

SSDP_ADDR = "239.255.255.250"
SSDP_PORT = 1900


def discover():
    """
    The main function of the ssdp.py file.

    Creates the SSDP Message,
    Receives and processes replies,
    Returns ip (as string) and port (as int).

    """
    message = "".join(["M-SEARCH * HTTP/1.1\r\n",
                       "Host: %s:%dr\n" % (SSDP_ADDR, SSDP_PORT),
                       "ST: urn:schemas-upnp-org:service:pilight:1\r\n",
                       "Man:\"ssdp:discover\"\r\n",
                       "MX:3\r\n\r\n"])

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.sendto(bytes(message, "utf,8"), (SSDP_ADDR, SSDP_PORT))
    while True:
        try:
            response = sock.recv(1024).decode()
            break
        except:
            print("No pilight SSDP connections found")
            break
    if len(response) > 0:
        rlocation = re.search('Location:([0-9.]+):([0-9.]+)',
                              str(response), re.IGNORECASE)
        if rlocation:
            ip = rlocation.group(1)
            port = int(rlocation.group(2))
            return ip, port
    sock.close(socket.SHUT_RDWR)

if __name__ == "__main__":
    ip, port = discover()
    print(ip + ":" + str(port))
