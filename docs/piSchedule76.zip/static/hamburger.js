		function setLocale(language, page) {
			console.log("	set 'Locale'  language:" + language)
			$.get('/locale', language, function() {
				location.replace(page);});
		};

		$('#hamburger').on('click', function(evt) {
			$("#hambgMenu")[0].classList.add('show')
			document.body.style.overflow = "hidden";
		});

		$("#hambgMenu").on('click', function(evt) {
			f = $("#hambgMenu")[0].classList.remove("show");
			evt.stopPropagation();
			document.body.style.overflow = "auto"
		});