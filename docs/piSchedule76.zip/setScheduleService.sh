#!/bin/bash
T="Set piSchedule Service        vers.2017-02-12_23"

H="
    SYNOPSIS  
       setScheduleService.sh 

    DESCRIPTION
       The 'piSchedule' is handled as a 'service'
       with:  sudo service piSchedule start|restart|stop

       This script sets the specific version stored in the same directory
       and prepares it for the 'service'

       Always run the script for a version change.  

    ARGUMENT
          no arguments   
"


VERSION=${PWD##*/}
SCHEDULE7=$HOME/$VERSION

 ##  echo " *** version  ***     -=$VERSION=-  "
 ##  echo " *** schedule ***     -=$SCHEDULE7=-  "
 ##  echo "---------------------------------------------"


   fg=$'\033[48;5;120m';
   fw=$'\e\033[48;5;123m';
   fr=$'\e\033[48;5;196m';
   ef=$'\e\033[0m';


   echo -e "\n
     $fw  $T     $ef"

   if ! [ -a $SCHEDULE7/piSchedule.sh.X ] ; then
       echo -e "\n
     $fr  piSchedule - Setup for 'service' calls               $ef
     $fr                                                       $ef
     $fr  NOTE                                                 $ef
     $fr    --  Make sure to start the function in the         $ef
     $fr        'piSchedule' directory which will be used!     $ef
     $fr    --  plight needs to be running                     $ef
       "

   else
         service pilight status > status.log
         rv=$?
         if ! [ "$rv" == "0" ] ; then
            echo -e "
           $fr                                                       $ef
           $fr  pilight  *** NOT working correctly! ***              $ef
           $fr                                                       $ef
           $fr  pilight needs to be running for piSchedule!          $ef
           $fr                                                       $ef
            \n"
            #cat status.log

            read -n 1 -p "           $fw    Start pilight ?  (Y/n)   ${ef} " A
            echo -e  "\n"

            if ! [ $A == 'Y' ] ; then
               exit 8
            fi

            sudo service pilight start
         fi

       rm status.log

       R='s#--DIR--#'$SCHEDULE7'#g'
       sed  $R $SCHEDULE7/piSchedule.sh.X > $SCHEDULE7/piSchedule.sh
   fi

   sudo cp $SCHEDULE7/piSchedule.sh /etc/init.d/piSchedule
   sudo update-rc.d piSchedule defaults
   sudo service piSchedule stop

   var=$(grep "DIR=" /etc/init.d/piSchedule) ;
   var1=${var##*/}

echo -e "\n
     $fg  piSchedule - HOW to START !                   $ef
     $fg                                                $ef
     $fg  Check above 'piDiscover pilight'              $ef
     $fg  ['server', 'port', 'pilight', 'sspd status']  $ef
     $fg                                                $ef
     $fw  Start piSchedule with                         $ef
     $fw    $  sudo service piSchedule start            $ef
     $fw                                                $ef
     $fg                                                $ef
     $fg  If failed, check with the following commands, $ef
     $fg  IMPORTANT: change to current piSchedule dirc  $ef
            $  cd ~/$var1

     $fg    $  service piSchedule status                $ef
     $fg    $  ./piPrefs.py                             $ef
     $fg    $  ./piDiscover.py                          $ef
     $fg    $  ps ax|grep piSchedule|grep python        $ef
     $fg                                                $ef
     $fg  See also log-file:                            $ef
     $fg    $  cat logs/piInfo.log                      $ef
     $fg    $  cat logs/piSystem.log                    $ef
     $fg                                                $ef
     $fw                                                $ef
     $fw  With valid results move over to your browser  $ef
     $fw  and start the 'piSchedule' home page using    $ef
     $fw  the prompted {server}:{port}                  $ef
     $fw                                                $ef
     \n"
     
     